<?php
require 'connection.php';

// Check if teacher_id is set in the GET request
if (!isset($_GET['teacher_id'])) {
    echo "Teacher ID not provided.";
    exit();
}

$id = (int) $_GET['teacher_id'];  // Typecast for safety

// Corrected SQL query with JOINs
$sql = "SELECT 
            teachers.teacher_name, 
            students.student_name, 
            subjects.subject_name, 
            grades.grade, 
            grades.date_recorded 
        FROM 
            grades 
        LEFT JOIN 
            teachers ON grades.teacher_id = teachers.teacher_id 
        LEFT JOIN 
            students ON grades.student_id = students.student_id 
        LEFT JOIN 
            subjects ON grades.subject_id = subjects.subject_id 
        WHERE 
            grades.teacher_id = $id";  // Filter by teacher_id to get only the specified teacher's data

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "No records found for this teacher.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title><?php echo htmlspecialchars($row['teacher_name']); ?>'s Classes and Grades</title>
</head>
<body>
    <div class="container">
        <h1><?php echo htmlspecialchars($row['teacher_name']); ?>'s Classes and Grades</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Subject Name</th>
                    <th>Grade</th>
                    <th>Date Recorded</th>
                </tr>
            </thead>
            <tbody>
                <?php
                do {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['student_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['subject_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['grade']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['date_recorded']) . "</td>";
                    echo "</tr>";
                } while ($row = $result->fetch_assoc());
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
