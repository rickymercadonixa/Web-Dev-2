<?php
require 'connection.php';

// Check if official_id is set in the GET request
if (!isset($_GET['teacher_id'])) {
    echo "Teacher ID not provided.";
    exit();
}

$id = (int)$_GET['teacher_id'];  // Typecast for safety

$sql = "SELECT * FROM teachers WHERE teacher_id = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Teacher not found";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($row['teacher_name']); ?>'s Profile</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>

<body>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteConfirmationModal" tabindex="-1" aria-labelledby="deleteConfirmationModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteConfirmationModalLabel">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this teacher profile?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a id="confirmDeleteBtn" href="#" class="btn btn-danger">Delete</a>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <!-- Display official's photo -->
        <div class="official-image">
            <img src="<?php echo htmlspecialchars($row['photo']); ?>" alt="Profile Picture of <?php echo htmlspecialchars($row['teacher_name']); ?>" width="150" height="150">
        </div>

        <!-- Display official's profile details -->
        <h1><?php echo htmlspecialchars($row['teacher_name']); ?>'s Profile</h1>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($row['email']); ?></p>
        <p><strong>Contact Number:</strong> <?php echo htmlspecialchars($row['contact_number']); ?></p>
        <p><strong>Birthdate:</strong> <?php echo htmlspecialchars($row['birthdate']); ?></p>
        <p><strong>Address:</strong> <?php echo htmlspecialchars($row['address']); ?></p>
        <a href='updateteacher_profile.php?teacher_id=<?php echo $row['teacher_id']; ?>' class='btn btn-info'>Update</a>
        <a href="#" class='btn btn-danger deleteBtn' data-id="<?php echo $row['teacher_id']; ?>" data-bs-toggle="modal" data-bs-target="#deleteConfirmationModal">Delete</a>
        <a href="admin_dashboard.php" class="btn btn-danger">Back</a>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var deleteButtons = document.querySelectorAll('.deleteBtn');
            var confirmDeleteBtn = document.getElementById('confirmDeleteBtn');

            deleteButtons.forEach(function(button) {
                button.addEventListener('click', function() {
                    var teacherId = this.getAttribute('data-id');
                    confirmDeleteBtn.setAttribute('href', 'deleteteacher_profile.php?teacher_id=' + teacherId);
                });
            });
        });
    </script>

</body>

</html>

<style>
    /* Reset some basic styles */
    body,
    h1,
    p {
        margin: 0;
        padding: 0;
    }

    /* Body styling */
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        color: #333;
    }

    /* Container for profile content */
    .container {
        max-width: 600px;
        margin: 50px auto;
        padding: 20px;
        background: white;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    /* Profile picture styling */
    .official-image img {
        border-radius: 50%;
        margin-bottom: 20px;
    }

    /* Headings and text */
    h1 {
        font-size: 28px;
        color: #333;
        margin-bottom: 10px;
    }

    p {
        font-size: 18px;
        color: #555;
        margin-bottom: 8px;
    }

    p strong {
        color: #222;
    }
</style>