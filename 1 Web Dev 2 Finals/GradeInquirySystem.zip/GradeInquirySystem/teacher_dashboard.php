<?php
require 'connection.php';

$teacher_id = $_SESSION['teacher_id'] ?? 0;
$query1 = "SELECT teacher_name FROM teachers WHERE teacher_id = ?";
$stmt = $conn->prepare($query1);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$teacher_name_result = $stmt->get_result();
$teacher_name = $teacher_name_result->fetch_assoc()['teacher_name'] ?? 'Teacher';

$query2 = "SELECT class_id FROM classes WHERE teacher_id = ?";
$stmt = $conn->prepare($query2);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$result = $stmt->get_result();

$class_ids = [];
while ($class = $result->fetch_assoc()) {
    $class_ids[] = $class['class_id'];
}

if (!empty($class_ids)) {
    $class_ids_str = implode(',', $class_ids);

    $students_query = "SELECT student_id, student_number, student_name FROM students WHERE class_id IN ($class_ids_str)";
    $students_result = $conn->query($students_query);

    $count_query = "SELECT COUNT(student_id) AS total_students FROM students WHERE class_id IN ($class_ids_str)";
    $count_result = $conn->query($count_query);
    $totalstudents = $count_result->fetch_assoc()['total_students'] ?? 0;
} else {
    $students_result = null;
    $totalstudents = 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Teacher Dashboard</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-3 sidebar">
            <div class="sidebar-header text-center mb-3">
                <img src="a-removebg-preview.png" alt="School Logo" class="img-fluid rounded-circle">
                <p class="mt-2">CEBUANO ELEMENTARY SCHOOL</p>
            </div>
            <nav class="nav flex-column nav-items">
                <a href="admin_dashboard.php" class="nav_link">Dashboard</a>
                <a href="teacher_addstudents.php" class="nav_link">Add Students</a>
                <a href="students.php" class="nav_link">Students</a>
            </nav>
            <a href="logout.php" class="btn btn-danger btn-logout mt-4">Logout</a>
        </div>
        
        <div class="col-md-9 main-content">
            <h2>Welcome, <?php echo $teacher_name?>!</h2>
            <h3 class="mb-4">Your Students</h3>
            
            <div class="row text-center mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Total Students</h4>
                            <h3 class="card-text display-4">
                                <?php echo $totalstudents ?>
                            </h3>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($students_result && $students_result->num_rows > 0): ?>
                <table class="table table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($student = $students_result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($student['student_number']) ?></td>
                                <td><?= htmlspecialchars($student['student_name']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-info">No students found for your classes.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f4f9;
    }
    .sidebar {
        background-color: #004d99;
        color: white;
        padding: 20px;
        min-height: 100vh;
    }
    .sidebar-header img {
        width: 80px;
        height: 80px;
    }
    .nav-items a {
        color: #fff;
        padding: 10px;
        text-align: center;
        display: block;
        margin-bottom: 10px;
        border-radius: 5px;
        transition: background-color 0.3s;
    }
    .nav-items a:hover {
        background-color: #003366;
    }
    .btn-logout {
        width: 100%;
    }
    .main-content {
        padding: 20px;
        background-color: #ffffff;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }
</style>
</body>
</html>
