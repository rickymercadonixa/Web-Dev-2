<?php
require 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Search Complaints</title>
</head>
<body>
<form action="" method="GET" class="mb-3">
    <h1 class="text-center">Search Complaint</h1>
    <div class="row justify-content-center">
        <div class="col-md-6">
    <div class="input-group">
    <a href="mngcomplaints.php" class="btn btn-danger">Back</a>
    <a href="searchcomplaint.php"  class="btn btn-primary me-4">Reset</a>
        <input type="text" class="form-control" placeholder="Search by resident name or complaint type" name="search">

        <button type="submit" class="btn btn-primary ms-4">Search</button>
    </div><br>
    </div>
    </div>
</form>

<?php

if (isset($_GET['search']) && !empty($_GET['search'])) {

    $search_query = $_GET['search'];

    $sql = "SELECT * FROM mngcomplaints WHERE resident_name LIKE '%$search_query%' or complaint_type LIKE '%$search_query%'";

    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        echo '<div class="table-responsive">';
        echo '<table class="table table-bordered">';
        echo '<thead class="table-dark">';
        echo '<tr>
                <th>Resident Name</th>
                <th>Complaint Type</th>
                <th>Description</th>
                <th>Date Filed</th>
                <th>Status</th>
                <th>Action</th>
            </tr>';
        echo '</thead>';

        echo '<tbody>';
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row["resident_name"] . "</td>";
            echo "<td>" . $row["complaint_type"] . "</td>";
            echo "<td>" . $row["description"] . "</td>";
            echo "<td>" . $row["date_filed"] . "</td>";
            echo "<td>" . $row["status"] . "</td>";
            echo "<td>
                    <a href='updatecomplaint.php?comp_id=" . $row['comp_id'] . "' class='btn btn-info btn-sm'>Update</a>
                    <a href='deletecomplaint.php?comp_id=" . $row['comp_id'] . "' class='btn btn-danger btn-sm'>Delete</a> 
                  </td>";
            echo "</tr>";
        }
        echo '</tbody>';
        echo '</table>';
        echo '</div>';
    } else {
        echo "<div class='alert alert-warning'>No complaint found.</div>";
    }
}
?>


</body>
</html>

<style>
    td img{
        object-fit: cover;
        border-radius: 5px;
    }

    th{
        text-align: center;
    }

    html{
        overflow-x: hidden;
    }
</style>
