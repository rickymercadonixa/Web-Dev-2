<?php
    session_start();

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "barangay";

    $conn = new mysqli(hostname: $servername, username: $username, password: $password, database: $database);

    if($conn -> connect_error){
        die("Connection Failed: ". $conn->connect_error);
    }
?>