<?php
    require 'connection.php';

    $cert_id = isset($_GET['cert_id']) ? $_GET['cert_id'] : null;

    if (!$cert_id) {
        die('No ID or Invalid ID');
    }

    if($_SERVER["REQUEST_METHOD"] == "POST"){

        $resident_name = $_POST['resident_name'];
        $certificate_type = $_POST['certificate_type'];
        $date_issued = $_POST['date_issued'];
        $valid_until = $_POST['valid_until'];

            $sql = "UPDATE mngcertificate SET resident_name = '$resident_name', certificate_type = '$certificate_type', date_issued = '$date_issued', valid_until = '$valid_until' WHERE cert_id = '$cert_id'";
        

        if ($conn->query($sql) === TRUE) {
            header("Location: viewcertificate.php");
            exit();
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }

    $sql = "SELECT * FROM mngcertificate WHERE cert_id = $cert_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        die('Certificate not found.');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Update Certificate</title>
</head>
<body>
<div class="form-container">
        <h1>Update Certificate Information</h1>

        <form action="" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="cert_id" value="<?php echo $row['cert_id']; ?>">

            <div class="mb-3">
                <label for="Resident Name" class="form-label">Resident Name:</label>
                <input type="text" class="form-control" name="resident_name" id="resident_name" value="<?php echo $row['resident_name']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="Certificate Type" class="form-label">Certificate type:</label>
                <input type="text" class="form-control" name="certificate_type" id="certificate_type" value="<?php echo $row['certificate_type']; ?>" required>
            </div>


            <div class="mb-3">
                <label for="date_issued" class="form-label">Date Issued:</label>
                <input type="datetime-local" class="form-control" name="date_issued" id="date_issued" value="<?php echo $row['date_issued']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="valid_until" class="form-label">Valid Until:</label>
                <input type="datetime-local" class="form-control" name="valid_until" id="valid_until" value="<?php echo $row['valid_until']; ?>" required>
            </div>

            <button type="submit" class="btn btn-primary">Update Certificate</button><br><br>
            <a href="viewcertificate.php" class="btn btn-danger col-md-12">Back</a>
        </form>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .form-container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-control {
            margin-bottom: 15px;
        }

        .btn-primary {
            width: 100%;
        }

        img {
            display: block;
            margin: 10px auto;
            width: 150px;
            height: auto;
            border-radius: 50%;
        }
    </style>
