<?php
    require 'connection.php';

    $clear_id = isset($_GET['clear_id']) ? $_GET['clear_id'] : null;

    if (!$clear_id) {
        die('No ID or Invalid ID');
    }

    if($_SERVER["REQUEST_METHOD"] == "POST"){

        $resident_name = $_POST['resident_name'];
        $clearance_type = $_POST['clearance_type'];
        $date_issued = $_POST['date_issued'];
        $status = $_POST['status'];

            $sql = "UPDATE mngclearance SET resident_name = '$resident_name', clearance_type = '$clearance_type', date_issued = '$date_issued', status = '$status' WHERE clear_id = '$clear_id'";
        

        if ($conn->query($sql) === TRUE) {
            header("Location: viewclearance.php");
            exit();
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }

    $sql = "SELECT * FROM mngclearance WHERE clear_id = $clear_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        die('Clearance not found.');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Update Clearance</title>
</head>
<body>
<div class="form-container">
        <h1>Update Clerance Information</h1>

        <form action="" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="clear_id" value="<?php echo $row['clear_id']; ?>">

            <div class="mb-3">
                <label for="Resident Name" class="form-label">Resident Name:</label>
                <input type="text" class="form-control" name="resident_name" id="resident_name" value="<?php echo $row['resident_name']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="Clearance Type" class="form-label">Clearance type:</label>
                <input type="text" class="form-control" name="clearance_type" id="clearance_type" value="<?php echo $row['clearance_type']; ?>" required>
            </div>


            <div class="mb-3">
                <label for="date_issued" class="form-label">Date Issued:</label>
                <input type="datetime-local" class="form-control" name="date_issued" id="date_issued" value="<?php echo $row['date_issued']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="status" class="form-label">Status:</label>
                <select class="form-select" name="status" id="status" required>
                    <option value="Pending" <?php if($row['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                    <option value="In Progress" <?php if($row['status'] == 'In Progress') echo 'selected'; ?>>In Progress</option>
                    <option value="Closed" <?php if($row['status'] == 'Closed') echo 'selected'; ?>>Closed</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Update Clearance</button><br><br>
            <a href="viewrclearance.php" class="btn btn-danger col-md-12">Back</a>
        </form>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .form-container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-control {
            margin-bottom: 15px;
        }

        .btn-primary {
            width: 100%;
        }

        img {
            display: block;
            margin: 10px auto;
            width: 150px;
            height: auto;
            border-radius: 50%;
        }
    </style>
