<?php
include 'connection.php';

header("Location: login.php");  

?>