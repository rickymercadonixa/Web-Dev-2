<?php
    require 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Add Officials</title>
</head>
<body>

<?php

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $name = $_POST['name'];
        $birthdate = $_POST['birthdate'];
        $position = $_POST['position'];
        $term_start = $_POST['term_start'];
        $term_end = $_POST['term_end'];
        $photo = $_POST['photo'];

        if(isset($_FILES["photo"]) && $_FILES["photo"]["error"] == 0){
            $photo_name = $_FILES['photo']['name'];
            $photo_tmp = $_FILES['photo']['tmp_name'];
            $photo_path = 'photo/' . $photo_name;

            if(move_uploaded_file($photo_tmp, $photo_path)){
                $sql = "INSERT INTO mngofficials (name,birthdate, position, term_start, term_end,photo)
                VALUES ('$name', '$birthdate', '$position', '$term_start', '$term_end', '$photo_path')";

                if($conn->query($sql)){
                    header("Location: mngofficials.php");
                    exit();
                }else{
                    echo "Error: ". $sql. "<br>" .$conn->error;
                }
            }else{
                echo 'Error Uploading file';
            }
        }else{
            echo 'No files uploaded. Please try again.';
        } 
    } 
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg">
                <div class="card-header bg-primary text-white text-center">
                    <h2>Add Officials</h2>
                </div>
                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <!-- Name -->
                        <div class="mb-3">
                            <label for="name" class="form-label">Name:</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        
                        <!-- Birthdate -->
                        <div class="mb-3">
                            <label for="birthdate" class="form-label">Birthdate</label>
                            <input type="date" class="form-control" id="birth_date" name="birthdate" required>
                        </div>

                        <!-- Position -->
                        <div class="mb-3">
                            <label for="position" class="form-label">Position</label>
                            <textarea class="form-control" id="position" name="position" rows="4" required></textarea>
                        </div>

                        <!-- Term start -->
                        <div class="mb-3">
                            <label for="termstart" class="form-label">Term Start</label>
                            <input type="date" class="form-control" id="term_start" name="term_start" required>
                        </div>

                          <!-- Term End -->
                          <div class="mb-3">
                            <label for="term_end" class="form-label">Term End</label>
                            <input type="date" class="form-control" id="term_end" name="term_end" required>
                        </div>

                            <!-- Photo -->
                        <div class="mb-3">
                            <label for="photo" class="form-label">Photo</label>
                            <input type="file" class="form-control" id="photo" name="photo" accept="image/*">
                        </div>

                        <!-- Submit Button -->
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-success">Add Official</button>
                            <a href="mngofficials.php" class="btn btn-danger">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

