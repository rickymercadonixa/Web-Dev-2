<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Manage Certificates</title>
</head>
<body>
    
<div class="d-flex">
    <div class="sidebar p-4 bg-primary">
        <img src="Systempics/barangay-labogon-mandaue-city-logo-png_seeklogo-528135.webp" alt="Barangay Logo">
        <p style="font-size: 30px; color: white;">Barangay Labogon</p>
        <div class="nav-items">
            <a href="dashboard.php" style="text-decoration: none; font-size: 1.2rem; color: white;" class="nav_link ">Dashboard</a><br><br>
            <a href="mngresidents.php" style="text-decoration: none; font-size: 1.2rem; color: white;" class="nav_link">Manage Residents</a><br><br>
            <a href="mngcomplaintsrequest.php" style="text-decoration: none; font-size: 1.2rem; color: white;" class="nav_link active">Manage Community Tax</a><br><br>
            <a href="mngofficials.php" style="text-decoration: none; font-size: 1.2rem; color: white;" class="nav_link">Manage Officials</a><br><br>
            <a href="viewreport.php" style="text-decoration: none; font-size: 1.2rem; color: white;" class="nav_link ">Manage Reports</a><br><br><br><br>
            <button class="btn btn-danger">Logout</button>
        </div>
    </div>

    <div class="main-content p-4"><br><br>
        <h2>Manage Community Tax</h2>
        <p>This is where you can manage residents community tax.</p>
        <a href="mngcomplaintsrequest.php" class="btn btn-danger">Back</a>
<br><br>

        <div class="row text-center">

            <!-- Stat Box 1 -->

            <div class="col-md-4">
                <div class="card  mb-3">
                    <div class="card-header bg-primary">
                        <p class="text-center" style="font-size: 2rem; color: white;">
                            View Community Tax
                        </p>
                        </div>
                    <div class="card-body">
                        <p class="card-title">See the list of all Community Ta.</p>
                        <a href="viewtax.php"  class="card-text btn btn-primary">Go to Community Tax List</a>
                    </div>
                </div>
            </div>

            <!-- Stat Box 2 -->

            <div class="col-md-4">
                <div class="card mb-3">
                <div class="card-header bg-primary">
                        <p class="text-center" style="font-size: 2rem; color: white;">
                            Search Community Tax
                        </p>
                        </div>
                    <div class="card-body">
                        <p class="card-title">Search for speicific tax to review or edit.</p>
                        <a href="searchtax.php"  class="card-text btn btn-primary">Search Community Tax</a>
                    </div>
                </div>
            </div>

            <!-- Stat Box 3 -->

            <div class="col-md-4">
                <div class="card  mb-3">
                <div class="card-header bg-primary">
                        <p class="text-center" style="font-size: 2rem; color: white;">
                            Create Community Tax
                        </p>
                        </div>
                    <div class="card-body">
                        <p class="card-title">File a new Community Tax.</p>
                        <a href="addtax.php"  class="card-text btn btn-primary">Create Community Tax</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.min.js"></script>
</body>
</html>

<style>
    .d-flex {
        display: flex;
        height: 100vh;
    }

    .sidebar {
        width: 250px;
        text-align: center;
    }

    .main-content {
        flex-grow: 1;
    }

    img {
        width: 100%;
    }

    .card-text {
        font-size: 1rem;
    }

    .active {
    background-color: darkblue;
    color: white; 
    border-radius: 5px; 
    padding: 5px; 
    }

    a:hover{
    background-color: darkblue;
    color: white; 
    border-radius: 5px; 
    padding: 5px; 
    }
</style>
