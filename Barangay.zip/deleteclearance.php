<?php
    require 'connection.php';
?>
<?php

    $clear_id = isset($_GET['clear_id']) ? $_GET['clear_id'] : null;
    
    if(!$clear_id){
        die('No ID or Invalid ID');
    }

    $sql = "DELETE FROM mngclearance WHERE clear_id = '$clear_id'";
    $conn -> query($sql);

    header("Location: viewclearance.php");
    exit();
?>