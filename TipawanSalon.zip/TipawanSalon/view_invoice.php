<?php
require 'connection.php';

// Check if the admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

// Get the invoice ID from the URL
if (isset($_GET['id'])) {
    $invoice_id = $_GET['id'];

    // Fetch the invoice details from the database
    $query = "SELECT * FROM invoice WHERE invoice_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $invoice_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $invoice = $result->fetch_assoc();

    if (!$invoice) {
        echo "Invoice not found.";
        exit();
    }
} else {
    echo "Invoice ID is missing.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Invoice</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="icon/fontawesome-free-6.7.1-web/css/all.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fa;
        }

        .container {
            margin-top: 50px;
            max-width: 800px;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #7e57c2;
        }

        .invoice-details {
            margin-top: 20px;
        }

        .invoice-details .row {
            margin-bottom: 10px;
        }

        .invoice-details .col-sm-3 {
            font-weight: bold;
            color: #333;
        }

        .invoice-details .col-sm-9 {
            color: #555;
        }

        .back-link {
            margin-top: 30px;
            text-align: center;
            font-size: 14px;
        }

        .back-link a {
            color: #7e57c2;
            text-decoration: none;
        }

        .back-link a:hover {
            text-decoration: underline;
        }

        .print-btn {
            text-align: center;
            margin-top: 20px;
        }

        .print-btn button {
            background-color: #7e57c2;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .print-btn button:hover {
            background-color: #6a4aa0;
        }

        @media print {
            .back-link {
                display: none; /* Hide the back link when printing */
            }

            .print-btn {
                display: none; /* Hide the print button when printing */
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Invoice Details</h2>
        <div class="invoice-details">
            <div class="row">
                <div class="col-sm-3">Invoice ID:</div>
                <div class="col-sm-9"><?php echo $invoice['invoice_id']; ?></div>
            </div>
            <div class="row">
                <div class="col-sm-3">Billing ID:</div>
                <div class="col-sm-9"><?php echo $invoice['billing_id']; ?></div>
            </div>
            <div class="row">
                <div class="col-sm-3">Posting Date:</div>
                <div class="col-sm-9"><?php echo $invoice['posting_date']; ?></div>
            </div>
        </div>

        <div class="print-btn">
            <button onclick="window.print()">Print Invoice</button>
        </div>
        
        <div class="back-link">
            <a href="invoices.php"><i class="fas fa-arrow-left"></i> Back to Invoice List</a>
        </div>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
