<?php
require 'connection.php';

$user_id = $_SESSION['user_id'];

$query = "SELECT service_id, ServiceName FROM services";
$result = $conn->query($query);

$today = date('Y-m-d');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $gender = $_POST['gender'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $service_id = $_POST['service'];

    // Insert the appointment first
    $query = "INSERT INTO appointment (user_id, name, email, mobile_number, gender, apt_date, apt_time, service_id) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("isssssss", $user_id, $name, $email, $mobile, $gender, $appointment_date, $appointment_time, $service_id);

    if ($stmt->execute()) {
        // Retrieve the inserted appointment ID
        $appointmentId = $stmt->insert_id; // Get the last inserted ID (apt_id)

        // Generate the billing ID based on the appointment
        $billing_id = "BILL" . time() . $user_id . $service_id; // Example: BILL<timestamp><user_id><service_id>

        // Insert the invoice using the appointment ID
        $invoice_query = "INSERT INTO invoice (user_id, service_id, apt_id, billing_id, posting_date) 
                          VALUES (?, ?, ?, ?, ?)";
        $invoice_stmt = $conn->prepare($invoice_query);
        $posting_date = date('Y-m-d H:i:s');
        $invoice_stmt->bind_param("iiiss", $user_id, $service_id, $appointmentId, $billing_id, $posting_date);

        if ($invoice_stmt->execute()) {
            echo '<script>
                    alert("Appointment booked successfully! Your Billing ID is: ' . $billing_id . '");
                    window.location.href = "index2.php";
                  </script>';
        } else {
            echo '<script>
                    alert("Failed to generate invoice. Please try again.");
                    window.location.href = "appointment.php";
                  </script>';
        }
    } else {
        echo '<script>
                alert("Failed to book the appointment. Please try again.");
                window.location.href = "appointment.php";
              </script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Form</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <style>
        /* General Styling */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f6ff;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #7e57c2; /* Purple Theme */
            color: #fff;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }
        .btn-primary {
            background-color: #7e57c2;
            border-color: #7e57c2;
        }
        .btn-primary:hover {
            background-color: #6a4aa0;
            border-color: #6a4aa0;
        }
        .form-control:focus {
            border-color: #7e57c2;
            box-shadow: 0 0 5px rgba(126, 87, 194, 0.5);
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-center">
                    <h4>Make an Appointment</h4>
                </div>
                <div class="card-body">
                <form method="POST" onsubmit="return confirmAppointment()">
                        <div class="mb-3">
                            <label for="name" class="form-label">Full Name</label>
                            <input type="text" name="name" id="name" class="form-control" placeholder="Enter your full name" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" name="email" id="email" class="form-control" placeholder="Enter your email" required>
                        </div>
                        <div class="mb-3">
                            <label for="mobile" class="form-label">Mobile Number</label>
                            <input type="number" name="mobile" id="mobile" class="form-control" placeholder="Enter your mobile number" required>
                        </div>
                        <div class="mb-3">
                            <label for="gender" class="form-label">Gender</label>
                            <select name="gender" id="gender" class="form-select" required>
                                <option value="" disabled selected>Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="appointment_date" class="form-label">Appointment Date</label>
                            <input type="date" name="appointment_date" id="appointment_date" class="form-control" min="<?php echo $today; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="appointment_time" class="form-label">Appointment Time</label>
                            <input type="time" name="appointment_time" id="appointment_time" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="service" class="form-label">Service</label>
                            <select name="service" id="service" class="form-select" required>
                                <option value="" disabled selected>Select Service</option>
                                <?php
                                if ($result && $result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo '<option value="' . $row['service_id'] . '">' . htmlspecialchars($row['ServiceName']) . '</option>';
                                    }
                                } else {
                                    echo '<option disabled>No services available</option>';
                                }
                                ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Book Appointment</button><br><br>

                        <a href="index2.php" class="btn btn-danger col-md-12">Back</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmAppointment() {
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const mobile = document.getElementById("mobile").value;
        const gender = document.getElementById("gender").value;
        const date = document.getElementById("appointment_date").value;
        const time = document.getElementById("appointment_time").value;
        const service = document.getElementById("service").options[document.getElementById("service").selectedIndex].text;

        // Create a confirmation message
        const message = `
Please confirm your appointment details:
- Name: ${name}
- Email: ${email}
- Mobile: ${mobile}
- Gender: ${gender}
- Date: ${date}
- Time: ${time}
- Service: ${service}

Click "OK" to confirm or "Cancel" to go back and edit.`;

        // Show confirmation dialog
        return confirm(message);
    }
</script>

</body>
</html>
