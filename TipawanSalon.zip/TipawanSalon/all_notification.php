<?php
require 'connection.php';

$user_id = $_SESSION['user_id'] ?? 0;

if (isset($_POST['mark_as_read'])) {
    $notification_id = $_POST['notification_id'];
    $mark_query = "UPDATE notification SET status = 'read' WHERE notif_id = ? AND user_id = ?";
    $mark_stmt = $conn->prepare($mark_query);
    $mark_stmt->bind_param("ii", $notification_id, $user_id);
    $mark_stmt->execute();
}

if (isset($_POST['delete'])) {
    $notification_id = $_POST['notif_id'];
    $delete_query = "DELETE FROM notification WHERE notif_id = ? AND user_id = ?";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param("ii", $notification_id, $user_id);
    $delete_stmt->execute();
}

$notifications_query = "SELECT notif_id, message, created, status FROM notification WHERE user_id = ? ORDER BY created DESC";
$notifications_stmt = $conn->prepare($notifications_query);
$notifications_stmt->bind_param("i", $user_id);
$notifications_stmt->execute();
$notifications_result = $notifications_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="icon/fontawesome-free-6.7.1-web/css/all.min.css">
    <title>All Notifications</title>
</head>
<body>
    <div class="container mt-4">
        <h1>All Notifications</h1>
        <?php if ($notifications_result->num_rows > 0): ?>
            <ul class="list-group">
                <?php while ($notification = $notifications_result->fetch_assoc()): ?>
                    <li class="list-group-item <?php echo $notification['status'] ? 'list-group-item-light' : ''; ?>">
                        <p><?php echo htmlspecialchars($notification['message']); ?></p>
                        <small><?php echo date('F j, Y, g:i a', strtotime($notification['created'])); ?></small>
                        <div class="mt-2">
                            <form method="post" class="d-inline">
                                <input type="hidden" name="notification_id" value="<?php echo $notification['notif_id']; ?>">
                                <button type="submit" name="mark_as_read" class="btn btn-sm btn-success"><i class="fa fa-check-square"></i> Mark as Read</button>
                            </form>
                            <form method="post" class="d-inline">
                                <input type="hidden" name="notif_id" value="<?php echo $notification['notif_id']; ?>">
                                <button type="submit" name="delete" class="btn btn-sm btn-danger"><i class="fas fa-trash-alt"></i> Delete</button>
                            </form>
                        </div>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>No notifications found.</p>
        <?php endif; ?>
        <br>
        <a href="index2.php" class="btn btn-primary">Back</a>
    </div>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
