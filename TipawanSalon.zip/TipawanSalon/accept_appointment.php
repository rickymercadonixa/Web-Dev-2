<?php
require 'connection.php'; // Include database connection

// Check if the admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

// Check if an appointment ID is provided in the URL
if (isset($_GET['id'])) {
    $apt_id = $_GET['id'];

    // Update the appointment status to 'Accepted'
    $query = "UPDATE appointment SET status = 'Accepted' WHERE apt_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $apt_id);

    if ($stmt->execute()) {
        // Redirect to manage appointments page with success message
        header("Location: manage_appointments.php?success1=1");
    } else {
        // Redirect to manage appointments page with error message
        header("Location: manage_appointments.php?error1=1");
    }
} else {
    // If no appointment ID is provided, redirect to manage appointments page
    header("Location: manage_appointments.php");
}
?>
