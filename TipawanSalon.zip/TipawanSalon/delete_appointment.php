<?php
require 'connection.php'; // Include the database connection

// Check if the admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

// Check if an appointment ID is provided in the URL
if (isset($_GET['id'])) {
    $appointmentId = $_GET['id'];

    // Start a transaction to ensure both actions are atomic
    $conn->begin_transaction();

    try {
        // 1. Delete the appointment from the appointment table
        $deleteQuery = "DELETE FROM appointment WHERE apt_id = ?";
        $deleteStmt = $conn->prepare($deleteQuery);
        $deleteStmt->bind_param("i", $appointmentId);

        if (!$deleteStmt->execute()) {
            throw new Exception('Error deleting appointment: ' . $deleteStmt->error);
        }

        // 2. Optionally, delete the associated invoice (if needed)
        // Make sure to check if invoices need to be deleted as well. For example:
        // $invoiceQuery = "DELETE FROM invoices WHERE apt_id = ?";
        // $invoiceStmt = $conn->prepare($invoiceQuery);
        // $invoiceStmt->bind_param("i", $appointmentId);
        // if (!$invoiceStmt->execute()) {
        //     throw new Exception('Error deleting invoice: ' . $invoiceStmt->error);
        // }

        // Commit the transaction if both queries are successful
        $conn->commit();

        // Redirect with success message
        header("Location: manage_appointments.php?success=1");
        exit();
    } catch (Exception $e) {
        // If an error occurs, rollback the transaction
        $conn->rollback();

        // Redirect with error message
        header("Location: manage_appointments.php?error=1");
        exit();
    }
} else {
    // If no appointment ID is provided, redirect back to the appointments page
    header("Location: manage_appointments.php");
    exit();
}
?>
