<?php
require 'connection.php'; // Include the database connection

// Check if the admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

// Check if the invoice ID is provided in the URL
if (isset($_GET['id'])) {
    $invoice_id = $_GET['id'];

    // Query to delete the invoice
    $query = "DELETE FROM invoice WHERE invoice_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $invoice_id);

    if ($stmt->execute()) {
        header("Location: invoices.php?success=true");
        exit();
    } else {
        echo "Error deleting invoice. Please try again.";
    }
} else {
    echo "Invoice ID is missing.";
    exit();
}
?>
