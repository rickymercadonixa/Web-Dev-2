<!--footer-->
<div class="footer">
    <p>&copy; 2024 Meraki's Salon Management System Admin Panel || Created by Russel M. Giducos</p>
</div>
<!--//footer-->