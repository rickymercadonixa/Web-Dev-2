<?php
    require 'connection.php';

    $tax_id = isset($_GET['tax_id']) ? $_GET['tax_id'] : null;

    if (!$tax_id) {
        die('No ID or Invalid ID');
    }

    if($_SERVER["REQUEST_METHOD"] == "POST"){

        $resident_name = $_POST['resident_name'];
        $tax_year = $_POST['tax_year'];
        $amount = $_POST['amount'];
        $date_paid = $_POST['date_paid'];

            $sql = "UPDATE mngtax SET resident_name = '$resident_name', tax_year = '$tax_year', amount = '$amount', date_paid = '$date_paid' WHERE tax_id = '$tax_id'";
        

        if ($conn->query($sql) === TRUE) {
            header("Location: viewtax.php");
            exit();
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }

    $sql = "SELECT * FROM mngtax WHERE tax_id = $tax_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        die('Tax not found.');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Update Community Tax</title>
</head>
<body>
<div class="form-container">
        <h1>Update Tax Information</h1>

        <form action="" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="tax_id" value="<?php echo $row['tax_id']; ?>">

            <div class="mb-3">
                <label for="Resident Name" class="form-label">Resident Name:</label>
                <input type="text" class="form-control" name="resident_name" id="resident_name" value="<?php echo $row['resident_name']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="tax_year" class="form-label">Tax Year:</label>
                <input type="date" class="form-control" name="tax_year" id="tax_year" value="<?php echo $row['tax_year']; ?>" required>
            </div>


            <div class="mb-3">
                <label for="amount" class="form-label">Amount:</label>
                <input type="number" class="form-control" name="amount" id="amount" value="<?php echo $row['amount']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="date_paid" class="form-label">Date Paid:</label>
                <input type="date" class="form-control" name="date_paid" id="date_paid" value="<?php echo $row['date_paid']; ?>" required>
            </div>

            <button type="submit" class="btn btn-primary">Update Tax</button><br><br>
            <a href="viewtax.php" class="btn btn-danger col-md-12">Back</a>
        </form>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .form-container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-control {
            margin-bottom: 15px;
        }

        .btn-primary {
            width: 100%;
        }

        img {
            display: block;
            margin: 10px auto;
            width: 150px;
            height: auto;
            border-radius: 50%;
        }
    </style>
