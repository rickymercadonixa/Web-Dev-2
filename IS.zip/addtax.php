<?php
    require 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Add Community Tax</title>
</head>
<body>

<?php

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $resident_name = $_POST['resident_name'];
        $tax_year = $_POST['tax_year'];
        $amount = $_POST['amount'];
        $date_paid = $_POST['date_paid'];

                $sql = "INSERT INTO mngtax (resident_name, tax_year, amount, date_paid)
                VALUES ('$resident_name', '$tax_year', '$amount', '$date_paid')";

                if($conn->query($sql)){
                    header("Location: viewtax.php");
                    exit();
                }else{
                    echo "Error: ". $sql. "<br>" .$conn->error;
                }  
            }
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg">
                <div class="card-header bg-primary text-white text-center">
                    <h2>Add Community Tax</h2>
                </div>
                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <!-- Resident Name -->
                        <div class="mb-3">
                            <label for="resident_name" class="form-label">Resident Name:</label>
                            <input type="text" class="form-control" id="resident_name" name="resident_name" required>
                        </div>
                        
                        <!-- Tax Year -->
                        <div class="mb-3">
                            <label for="tax_year" class="form-label">Tax Year</label>
                            <input type="text" class="form-control" id="tax_year" name="tax_year" required>
                        </div>

                        <!-- Amount -->
                        <div class="mb-3">
                            <label for="amount" class="form-label">Amount</label>
                            <input type="number" class="form-control" id="amount" name="amount" rows="4" required></input>
                        </div>

                        <!-- Date Paid -->
                        <div class="mb-3">
                            <label for="date_paid" class="form-label">Date Paid</label>
                            <input type="date" class="form-control" id="date_paid" name="date_paid" required>
                        </div>

                        <!-- Submit Button -->
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-success">Add Tax</button>
                            <a href="residentsmanagetax.php" class="btn btn-danger">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

