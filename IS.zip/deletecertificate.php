<?php
    require 'connection.php';
?>
<?php

    $cert_id = isset($_GET['cert_id']) ? $_GET['cert_id'] : null;
    
    if(!$cert_id){
        die('No ID or Invalid ID');
    }

    $sql = "DELETE FROM mngcertificate WHERE cert_id = '$cert_id'";
    $conn -> query($sql);

    header("Location: viewcertificate.php");
    exit();
?>