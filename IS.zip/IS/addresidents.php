<?php
    require 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Add Residents</title>
</head>
<body>

<?php


    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $firstname = $_POST['firstname'];
        $middlename = $_POST['middlename'];
        $lastname = $_POST['lastname'];
        $nickname = $_POST['nickname'];
        $gender = $_POST['gender'];
        $birth_date = $_POST['birth_date'];
        $place_of_birth = $_POST['place_of_birth'];
        $civil_status = $_POST['civil_status'];
        $occupation = $_POST['occupation'];
        $religion = $_POST['religion'];
        $lot = $_POST['lot'];
        $purok = $_POST['purok'];
        $residents_status = $_POST['residents_status'];
        $voters_status = $_POST['voters_status'];
        $pwd = $_POST['pwd'];
        $email = $_POST['email'];
        $phone_number = $_POST['phone_number'];
        $telephone = $_POST['telephone'];

        if(isset($_FILES["photo"]) && $_FILES["photo"]["error"] == 0){
            $photo_name = $_FILES['photo']['name'];
            $photo_tmp = $_FILES['photo']['tmp_name'];
            $photo_path = 'photo/' . $photo_name;

            if(move_uploaded_file($photo_tmp, $photo_path)){
                $sql = "INSERT INTO mngresidents (firstname,middlename, lastname, nickname, gender,birth_date, place_of_birth, civil_status, occupation, religion, lot, purok, residents_status, voters_status, pwd, email, phone_number, telephone, photo)
                VALUES ('$firstname', '$middlename', '$lastname', '$nickname', '$gender', '$birth_date', '$place_of_birth', '$civil_status', '$occupation', '$religion', '$lot', '$purok', '$residents_status', '$voters_status', '$pwd', '$email', '$phone_number', '$telephone', '$photo_path')";

                if($conn->query($sql)){
                    header("Location: readresidents.php");
                    exit();
                }else{
                    echo "Error: ". $sql. "<br>" .$conn->error;
                }
            }else{
                echo 'Error Uploading file';
            }
        }else{
            echo 'No files uploaded. Please try again.';
        }      
    }
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg">
                <div class="card-header bg-primary text-white text-center">
                    <h2>Add Resident</h2>
                </div>
                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <!-- First Name -->
                        <div class="mb-3">
                            <label for="firstname" class="form-label">First Name</label>
                            <input type="text" class="form-control" id="firstname" name="firstname" required>
                        </div>
                        
                        <!-- Middle Name -->
                        <div class="mb-3">
                            <label for="middlename" class="form-label">Middle Name</label>
                            <input type="text" class="form-control" id="middlename" name="middlename" required>
                        </div>

                        <!-- Last Name -->
                        <div class="mb-3">
                            <label for="lastname" class="form-label">Last Name</label>
                            <input type="text" class="form-control" id="lastname" name="lastname" required>
                        </div>

                        <!-- Nickname -->
                        <div class="mb-3">
                            <label for="nickname" class="form-label">Nickname</label>
                            <input type="text" class="form-control" id="nickname" name="nickname">
                        </div>

                        <!-- Gender -->
                        <div class="mb-3">
                            <label for="gender" class="form-label">Gender</label>
                            <select class="form-select" id="gender" name="gender" required>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>

                        <!-- Birth Date -->
                        <div class="mb-3">
                            <label for="birth_date" class="form-label">Birth Date</label>
                            <input type="date" class="form-control" id="birth_date" name="birth_date" required>
                        </div>

                        <!-- Place of Birth -->
                        <div class="mb-3">
                            <label for="place_of_birth" class="form-label">Place of Birth</label>
                            <input type="text" class="form-control" id="place_of_birth" name="place_of_birth" required>
                        </div>

                        <!-- Civil Status -->
                        <div class="mb-3">
                            <label for="civil_status" class="form-label">Civil Status</label>
                            <select class="form-select" id="civil_status" name="civil_status" required>
                                <option value="Single">Single</option>
                                <option value="Married">Married</option>
                                <option value="Widowed">Widowed</option>
                                <option value="Divorced">Divorced</option>
                            </select>
                        </div>

                        <!-- Occupation -->
                        <div class="mb-3">
                            <label for="occupation" class="form-label">Occupation</label>
                            <input type="text" class="form-control" id="occupation" name="occupation">
                        </div>

                        <!-- Religion -->
                        <div class="mb-3">
                            <label for="religion" class="form-label">Religion</label>
                            <input type="text" class="form-control" id="religion" name="religion">
                        </div>

                        <!-- Lot -->
                        <div class="mb-3">
                            <label for="lot" class="form-label">Lot</label>
                            <input type="text" class="form-control" id="lot" name="lot">
                        </div>

                        <!-- Purok -->
                        <div class="mb-3">
                            <label for="purok" class="form-label">Purok</label>
                            <input type="text" class="form-control" id="purok" name="purok">
                        </div>

                        <!-- Resident Status -->
                        <div class="mb-3">
                            <label for="residents_status" class="form-label">Resident Status</label>
                            <select class="form-select" id="residents_status" name="residents_status">
                                <option value="Permanent">Permanent</option>
                                <option value="Temporary">Temporary</option>
                            </select>
                        </div>

                        <!-- Voter's Status -->
                        <div class="mb-3">
                            <label for="voters_status" class="form-label">Voter's Status</label>
                            <select class="form-select" id="voters_status" name="voters_status">
                                <option value="Registered">Registered</option>
                                <option value="Not Registered">Not Registered</option>
                            </select>
                        </div>

                        <!-- PWD Status -->
                        <div class="mb-3">
                            <label for="pwd" class="form-label">PWD</label>
                            <select class="form-select" id="pwd" name="pwd">
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>

                        <!-- Email -->
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>

                        <!-- Phone Number -->
                        <div class="mb-3">
                            <label for="phone_number" class="form-label">Phone Number</label>
                            <input type="text" class="form-control" id="phone_number" name="phone_number">
                        </div>

                        <!-- Telephone -->
                        <div class="mb-3">
                            <label for="telephone" class="form-label">Telephone</label>
                            <input type="text" class="form-control" id="telephone" name="telephone">
                        </div>

                        <!-- Photo -->
                        <div class="mb-3">
                            <label for="photo" class="form-label">Photo</label>
                            <input type="file" class="form-control" id="photo" name="photo" accept="image/*">
                        </div>

                        <!-- Submit Button -->
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-success">Add Resident</button>
                            <a href="mngresidents.php" class="btn btn-danger">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

