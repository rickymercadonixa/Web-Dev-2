const nav = document.querySelectorAll('.nav_link');

navlink.forEach(navlinks => {
    navlinks.addEventlistener('ckick', () => {
        document.querySelector('.active').classList.remove('active');
        navlinks.classList.add('active');
    });
});