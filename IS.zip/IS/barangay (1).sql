-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2024 at 09:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `barangay`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`) VALUES
(2, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `mngresidents`
--

CREATE TABLE `mngresidents` (
  `resd_id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `middlename` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `birth_date` date NOT NULL,
  `place_of_birth` text NOT NULL,
  `civil_status` varchar(20) NOT NULL,
  `occupation` varchar(30) NOT NULL,
  `religion` varchar(20) NOT NULL,
  `lot` tinyint(4) NOT NULL,
  `purok` varchar(30) NOT NULL,
  `residents_status` varchar(20) NOT NULL,
  `voters_status` varchar(20) NOT NULL,
  `pwd` varchar(4) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `telephone` varchar(30) NOT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mngresidents`
--

INSERT INTO `mngresidents` (`resd_id`, `firstname`, `middlename`, `lastname`, `nickname`, `gender`, `birth_date`, `place_of_birth`, `civil_status`, `occupation`, `religion`, `lot`, `purok`, `residents_status`, `voters_status`, `pwd`, `email`, `phone_number`, `telephone`, `photo`) VALUES
(1, 'Ricky', 'Borja', 'Mercado', 'RikRik', 'Male', '2024-09-28', 'Heramil Hospital General Santos City', 'Single', 'Student', 'Roman Catholic', 1, '12', 'Permanent', 'Registered', 'No', 'asdasdasd@gmail.com', '09092034481', 'asdasdsadasd', 'photo/Messenger_creation_C78BEB55-EF82-43D5-A390-1BC24CF1D091.jpeg'),
(2, 'Jalmer', 'Borja', 'Mercado', 'Mer', 'Male', '2024-09-06', 'Heramil Hospital South Cotabato', 'Single', 'Forklift', 'Roman Catholic', 2, '2', 'Permanent', 'Registered', 'No', 'jalmer@example.com', '09092034481', '4545-656-5656', 'photo/sd.jpg'),
(3, 'Wesley', 'Roselo', 'Borja', 'Thuderpiglits', 'Male', '2024-02-14', 'Sa balay lng', 'Married', 'Student', 'Catholic', 3, '3', 'Permanent', 'Not Registered', 'Yes', 'wesley@example.com', '09999445565', '4545-656-5656', 'photo/sd.jpg'),
(5, 'Vanixa', 'Anisha', 'Pacatua', 'Nixa', 'Female', '2004-10-25', 'Cebu City', 'Single', 'Student/Businesswoman', 'Catholic', 1, '3', 'Permanent', 'Registered', 'No', 'vanixa@example.com', '09092034481', '4455-5544-66', 'photo/Messenger_creation_C78BEB55-EF82-43D5-A390-1BC24CF1D091.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `mngresidents`
--
ALTER TABLE `mngresidents`
  ADD PRIMARY KEY (`resd_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mngresidents`
--
ALTER TABLE `mngresidents`
  MODIFY `resd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
