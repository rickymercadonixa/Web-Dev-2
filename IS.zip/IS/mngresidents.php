<?php
    require 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Manage Residents</title>
</head>
<body>

<?php


    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $firstname = $_POST['firstname'];
        $middlename = $_POST['middlename'];
        $lastname = $_POST['lastname'];
        $nickname = $_POST['nickname'];
        $gender = $_POST['gender'];
        $birth_date = $_POST['birth_date'];
        $place_of_birth = $_POST['place_of_birth'];
        $civil_status = $_POST['civil_status'];
        $occupation = $_POST['occupation'];
        $religion = $_POST['religion'];
        $lot = $_POST['lot'];
        $purok = $_POST['purok'];
        $residents_status = $_POST['residents_status'];
        $voters_status = $_POST['voters_status'];
        $pwd = $_POST['pwd'];
        $email = $_POST['email'];
        $phone_number = $_POST['phone_number'];
        $telephone = $_POST['telephone'];

        $sql = "INSERT INTO myguests (firstname,middlename, lastname, nickname, gender,birth_date, place_of_birth, civil_status, occupation, religion, lot, purok, residents_status, voters_status, pwd, email, phone_number, telephone= )
                VALUES ('$firstname', '$lastname', '$email', '$reg_date')";

                if($conn->query($sql)){
                    header("Location: dashboard.php");
                    exit();
                }else{
                    echo "Error: ". $sql. "<br>" .$conn->error;
                }
            
    }
?>

<div class="d-flex">
    <!-- Sidebar -->
    <div class="sidebar p-4">
        <img src="Green_Vintage_Agriculture_and_Farming_Logo-removebg-preview.png" alt="">
        <p style="font-size: 30px;">Barangay Abayon</p>
        <div class="nav-items">
            <a href="dashboard.php">Dashboard</a><br><br>
            <a href="mngresidents.php">Manage Residents</a><br><br>
            <a href="#">Manage Complaints</a><br><br>
            <a href="#">Manage Officials</a><br><br><br><br>
            <button class="btn btn-danger">Logout</button>
        </div>
    </div>
</body>
</html>

<style>
    .d-flex {
        display: flex;
        height: 100vh; /* Full height */
    }

    .sidebar {
        width: 250px;
        text-align: center;
    }

    .main-content {
        flex-grow: 1; /* Takes the remaining space */
    }

    img {
        width: 100%;
    }

    .card-text {
        font-size: 2.5rem;
        font-weight: bold;
    }
</style>
