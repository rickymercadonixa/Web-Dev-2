<?php
    require 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Resident Records</title>

    <style>
        /* Add some padding to the container */
        .container {
            margin-top: 30px;
        }

        /* Customize the search form */
        .input-group .form-control {
            border-radius: 0.25rem;
        }

        /* Style for the search button */
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        /* Make the table more compact */
        .table th, .table td {
            vertical-align: middle;
            text-align: center;
        }

        /* Style the image column to prevent distortion */
        td img {
            object-fit: cover;
            border-radius: 5px;
        }

        /* Highlight table rows on hover */
        .table-hover tbody tr:hover {
            background-color: #f2f2f2;
        }

        /* Button customization */
        .btn-sm {
            font-size: 0.85rem;
            padding: 0.4rem 0.75rem;
        }

        /* Mobile responsiveness */
        @media (max-width: 768px) {
            td img {
                width: 50px;
                height: 50px;
            }

            .btn-sm {
                padding: 0.3rem 0.5rem;
            }

            /* Optional: Make table scrollable on small screens */
            .table-responsive {
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2 class="mb-4 text-center">Resident Records</h2>
    <a href="mngresidents.php" class="btn btn-danger">Back</a><br><br>

    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteModalLabel">Delete Resident</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to delete this resident?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <a href="#" class="btn btn-danger" id="confirmDeleteBtn">Delete</a>
      </div>
    </div>
  </div>
</div>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>Photo</th>
                    <th>First Name</th>
                    <th>Middle Name</th>
                    <th>Last Name</th>
                    <th>Nickname</th>
                    <th>Gender</th>
                    <th>Birth Date</th>
                    <th>Place of Birth</th>
                    <th>Civil Status</th>
                    <th>Occupation</th>
                    <th>Religion</th>
                    <th>Lot</th>
                    <th>Purok</th>
                    <th>Resident Status</th>
                    <th>Voter Status</th>
                    <th>PWD</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Telephone</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>

            <?php
                    $sql = "SELECT * FROM mngresidents";


                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td><img src='" . $row["photo"] . "' width='100' height='100'></td>";
                        echo "<td>" . $row["firstname"] . "</td>";
                        echo "<td>" . $row["middlename"] . "</td>";
                        echo "<td>" . $row["lastname"] . "</td>";
                        echo "<td>" . $row["nickname"] . "</td>";
                        echo "<td>" . $row["gender"] . "</td>";
                        echo "<td>" . $row["birth_date"] . "</td>";
                        echo "<td>" . $row["place_of_birth"] . "</td>";
                        echo "<td>" . $row["civil_status"] . "</td>";
                        echo "<td>" . $row["occupation"] . "</td>";
                        echo "<td>" . $row["religion"] . "</td>";
                        echo "<td>" . $row["lot"] . "</td>";
                        echo "<td>" . $row["purok"] . "</td>";
                        echo "<td>" . $row["residents_status"] . "</td>";
                        echo "<td>" . $row["voters_status"] . "</td>";
                        echo "<td>" . $row["pwd"] . "</td>";
                        echo "<td>" . $row["email"] . "</td>";
                        echo "<td>" . $row["phone_number"] . "</td>";
                        echo "<td>" . $row["telephone"] . "</td>";
                        echo "<td>
                                <a href='update.php?resd_id=" . $row['resd_id'] . "' class='btn btn-info btn-sm'>Update</a>||||||||||||||||
                                <a href='#' class='btn btn-danger deleteBtn' data-id='".$row["resd_id"]."' data-bs-toggle='modal' data-bs-target='#deleteModal'>Delete</a> 
                      </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='20' class='alert alert-warning'>No records found</td></tr>";
                }
            ?>

            </tbody>
        </table>
    </div>
</div>
<script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var deleteButtons = document.querySelectorAll('.deleteBtn');
    var confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
    
    deleteButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            var userId = this.getAttribute('data-id');
            confirmDeleteBtn.setAttribute('href', 'delete.php?resd_id=' + userId);
        });
    });
});
</script>
</body>
</html>
