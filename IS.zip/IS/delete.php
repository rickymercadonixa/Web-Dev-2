<?php
    require 'connection.php';
?>
<?php

    $resd_id = isset($_GET['resd_id']) ? $_GET['resd_id'] : null;
    
    if(!$resd_id){
        die('No ID or Invalid ID');
    }

    $sql = "DELETE FROM mngresidents WHERE resd_id = '$resd_id'";
    $conn -> query($sql);

    header("Location: readresidents.php");
    exit();
?>