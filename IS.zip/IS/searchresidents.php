<?php
require 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Search Residents</title>
</head>
<body>
<form action="" method="GET" class="mb-3">
    <h1 class="text-center">Search Residents</h1>
    <div class="row justify-content-center">
        <div class="col-md-6">
    <div class="input-group">
    <a href="mngresidents.php" class="btn btn-danger">Back</a>
    <a href="searchresidents.php"  class="btn btn-primary me-4">Reset</a>
        <input type="text" class="form-control" placeholder="Search by first or last name" name="search">

        <button type="submit" class="btn btn-primary ms-4">Search</button>
    </div><br>
    </div>
    </div>
</form>

<?php

if (isset($_GET['search']) && !empty($_GET['search'])) {

    $search_query = $_GET['search'];
    $sql = "SELECT * FROM mngresidents WHERE firstname LIKE '%$search_query%' OR lastname LIKE '%$search_query%'";

    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        echo '<div class="table-responsive">';
        echo '<table class="table table-bordered">';
        echo '<thead class="table-dark">';
        echo '<tr>
                <th>Photo</th>
                <th>First Name</th>
                <th>Middle Name</th>
                <th>Last Name</th>
                <th>Nickname</th>
                <th>Gender</th>
                <th>Birth Date</th>
                <th>Place of Birth</th>
                <th>Civil Status</th>
                <th>Occupation</th>
                <th>Religion</th>
                <th>Lot</th>
                <th>Purok</th>
                <th>Resident Status</th>
                <th>Voter Status</th>
                <th>PWD</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Telephone</th>
                <th>Action</th>
            </tr>';
        echo '</thead>';
        echo '<tbody>';

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td><img src='" . $row['photo'] . "' width='100' height='100'></td>";
            echo "<td>" . $row['firstname'] . "</td>";
            echo "<td>" . $row['middlename'] . "</td>";
            echo "<td>" . $row['lastname'] . "</td>";
            echo "<td>" . $row['nickname'] . "</td>";
            echo "<td>" . $row['gender'] . "</td>";
            echo "<td>" . $row['birth_date'] . "</td>";
            echo "<td>" . $row['place_of_birth'] . "</td>";
            echo "<td>" . $row['civil_status'] . "</td>";
            echo "<td>" . $row['occupation'] . "</td>";
            echo "<td>" . $row['religion'] . "</td>";
            echo "<td>" . $row['lot'] . "</td>";
            echo "<td>" . $row['purok'] . "</td>";
            echo "<td>" . $row['residents_status'] . "</td>";
            echo "<td>" . $row['voters_status'] . "</td>";
            echo "<td>" . $row['pwd'] . "</td>";
            echo "<td>" . $row['email'] . "</td>";
            echo "<td>" . $row['phone_number'] . "</td>";
            echo "<td>" . $row['telephone'] . "</td>";
            echo "<td>
                    <a href='update.php?resd_id=" . $row['resd_id'] . "' class='btn btn-info btn-sm'>Update</a>||||||||||||||||
                    <a href='delete.php?resd_id=" . $row['resd_id'] . "' class='btn btn-danger btn-sm'>Delete</a> 
                  </td>";
            echo "</tr>";
        }

        echo '</tbody>';
        echo '</table>';
        echo '</div>';
    } else {
        echo "<div class='alert alert-warning'>No residents found.</div>";
    }
}
?>

</body>
</html>

<style>
    td img{
        object-fit: cover;
        border-radius: 5px;
    }

    th{
        text-align: center;
    }

    html{
        overflow-x: hidden;
    }
</style>
