-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2024 at 01:11 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `barangay`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`) VALUES
(2, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `mngcertificate`
--

CREATE TABLE `mngcertificate` (
  `cert_id` int(11) NOT NULL,
  `resident_name` varchar(50) NOT NULL,
  `certificate_type` varchar(20) NOT NULL,
  `date_issued` datetime NOT NULL,
  `valid_until` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mngcertificate`
--

INSERT INTO `mngcertificate` (`cert_id`, `resident_name`, `certificate_type`, `date_issued`, `valid_until`) VALUES
(1, 'Ricky Mercado', 'Honorses', '2024-09-26 08:48:00', '2025-12-31 08:48:00');

-- --------------------------------------------------------

--
-- Table structure for table `mngclearance`
--

CREATE TABLE `mngclearance` (
  `clear_id` int(11) NOT NULL,
  `resident_name` varchar(50) NOT NULL,
  `clearance_type` varchar(20) NOT NULL,
  `date_issued` datetime NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mngclearance`
--

INSERT INTO `mngclearance` (`clear_id`, `resident_name`, `clearance_type`, `date_issued`, `status`) VALUES
(1, 'Ricky Mercado', 'Barangay', '2024-09-25 17:11:00', 'Pending'),
(4, 'Ricky Mercado', 'Barangay', '2024-09-25 17:03:00', 'Closed');

-- --------------------------------------------------------

--
-- Table structure for table `mngcomplaints`
--

CREATE TABLE `mngcomplaints` (
  `comp_id` int(11) NOT NULL,
  `resident_name` varchar(20) NOT NULL,
  `complaint_type` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `date_filed` datetime NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mngcomplaints`
--

INSERT INTO `mngcomplaints` (`comp_id`, `resident_name`, `complaint_type`, `description`, `date_filed`, `status`) VALUES
(9, 'Sino ka wes', 'Saba kaayo si wesley', 'Bak wesley toe', '2024-09-24 16:46:00', 'In Progress'),
(10, 'Bacas', 'Hi', 'Hello', '2024-09-25 08:21:00', 'Pending'),
(12, 'Ricky Mercado', 'Noise', 'Saba kaayo sila yawa', '2024-09-25 08:57:00', 'Pending'),
(13, 'asd', 'a', 'asd', '2024-09-25 09:14:00', 'Closed');

-- --------------------------------------------------------

--
-- Table structure for table `mngresidents`
--

CREATE TABLE `mngresidents` (
  `resd_id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `middlename` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `birth_date` date NOT NULL,
  `place_of_birth` text NOT NULL,
  `civil_status` varchar(20) NOT NULL,
  `occupation` varchar(30) NOT NULL,
  `religion` varchar(20) NOT NULL,
  `lot` tinyint(4) NOT NULL,
  `purok` varchar(30) NOT NULL,
  `residents_status` varchar(20) NOT NULL,
  `voters_status` varchar(20) NOT NULL,
  `pwd` varchar(4) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `telephone` varchar(30) NOT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mngresidents`
--

INSERT INTO `mngresidents` (`resd_id`, `firstname`, `middlename`, `lastname`, `nickname`, `gender`, `birth_date`, `place_of_birth`, `civil_status`, `occupation`, `religion`, `lot`, `purok`, `residents_status`, `voters_status`, `pwd`, `email`, `phone_number`, `telephone`, `photo`) VALUES
(8, 'Ricky', 'Borja1', 'Mercado', 'Thuderpiglits', 'Male', '2024-09-24', 'Heramil Hospital South Cotabato', 'Single', 'Student', 'Roman Catholic', 1, '3', 'Permanent', 'Registered', 'No', 'asdasdasd@gmail.com', '09092034481', '4545-656-5656', 'photo/sd.jpg'),
(9, 'asd', 'asd', 'asd', 'asd', 'Male', '2024-09-25', 'asd', 'Single', 'asda', 'asd', 1, '1', 'Permanent', 'Registered', 'Yes', 'asdasdasd@gmail.com', 'asd', 'asd', 'photo/IMG_20231204_184057_779.jpg'),
(10, 'asd', 'asd', 'asd', 'asdasd', 'Male', '2024-09-25', 'asd', 'Single', 'asd', 'asd', 1, '1', 'Permanent', 'Registered', 'Yes', 'asdasdasd@gmail.com', 'asd', 'asddddd', 'photo/452152025_394729619820089_7145951078922959525_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `mngtax`
--

CREATE TABLE `mngtax` (
  `tax_id` int(11) NOT NULL,
  `resident_name` varchar(50) NOT NULL,
  `tax_year` year(4) NOT NULL,
  `amount` int(11) NOT NULL,
  `date_paid` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mngtax`
--

INSERT INTO `mngtax` (`tax_id`, `resident_name`, `tax_year`, `amount`, `date_paid`) VALUES
(1, 'Ricky Mercado', '2024', 100000, '2024-09-26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `mngcertificate`
--
ALTER TABLE `mngcertificate`
  ADD PRIMARY KEY (`cert_id`);

--
-- Indexes for table `mngclearance`
--
ALTER TABLE `mngclearance`
  ADD PRIMARY KEY (`clear_id`);

--
-- Indexes for table `mngcomplaints`
--
ALTER TABLE `mngcomplaints`
  ADD PRIMARY KEY (`comp_id`);

--
-- Indexes for table `mngresidents`
--
ALTER TABLE `mngresidents`
  ADD PRIMARY KEY (`resd_id`);

--
-- Indexes for table `mngtax`
--
ALTER TABLE `mngtax`
  ADD PRIMARY KEY (`tax_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mngcertificate`
--
ALTER TABLE `mngcertificate`
  MODIFY `cert_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mngclearance`
--
ALTER TABLE `mngclearance`
  MODIFY `clear_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mngcomplaints`
--
ALTER TABLE `mngcomplaints`
  MODIFY `comp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `mngresidents`
--
ALTER TABLE `mngresidents`
  MODIFY `resd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `mngtax`
--
ALTER TABLE `mngtax`
  MODIFY `tax_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
