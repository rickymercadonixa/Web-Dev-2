<?php
    require 'connection.php';
?>
<?php

    $tax_id = isset($_GET['tax_id']) ? $_GET['tax_id'] : null;
    
    if(!$tax_id){
        die('No ID or Invalid ID');
    }

    $sql = "DELETE FROM mngtax WHERE tax_id = '$tax_id'";
    $conn -> query($sql);

    header("Location: viewtax.php");
    exit();
?>