<?php
    require 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="shortcut icon" href="Systempics/barangay-labogon-mandaue-city-logo-png_seeklogo-528135.webp" type="image/x-icon">
    <title>Admin Dashboard</title>
</head>
<body>

    <?php
        $totalhousehold = "SELECT COUNT(DISTINCT CONCAT(purok, '-', lot)) as total_households from mngresidents";
        $totalhouseholdresult = mysqli_query($conn, query: $totalhousehold);
        $totalhouseholds = mysqli_fetch_assoc($totalhouseholdresult)['total_households'] ?? 0;

        $totalpopulation = "SELECT COUNT(resd_id) as total_population from mngresidents";
        $totalpopulationresult = mysqli_query($conn, query: $totalpopulation);
        $totalpopulations = mysqli_fetch_assoc($totalpopulationresult)['total_population'] ?? 0;

        $totalmale= "SELECT COUNT(resd_id) as total_male from mngresidents WHERE gender = 'male'";
        $totalmaleresult = mysqli_query($conn, query: $totalmale);
        $totalmales = mysqli_fetch_assoc($totalmaleresult)['total_male'] ?? 0;

        $totalfemale= "SELECT COUNT(resd_id) as total_female from mngresidents WHERE gender = 'female'";
        $totalfemaleresult = mysqli_query($conn, query: $totalfemale);
        $totalfemales = mysqli_fetch_assoc($totalfemaleresult)['total_female'] ?? 0;

        $totalchildren= "SELECT COUNT(resd_id) as total_children from mngresidents WHERE TIMESTAMPDIFF(YEAR, birth_date, CURDATE()) < 18";
        $totalchildrenresult = mysqli_query($conn, query: $totalchildren);
        $totalchildrens = mysqli_fetch_assoc($totalchildrenresult)['total_children'] ?? 0;

        $totalsenior= "SELECT COUNT(resd_id) as total_senior from mngresidents WHERE TIMESTAMPDIFF(YEAR, birth_date, CURDATE()) >= 60";
        $totalseniorresult = mysqli_query($conn, query: $totalsenior);
        $totalseniors = mysqli_fetch_assoc($totalseniorresult)['total_senior'] ?? 0;

        $totaladult= "SELECT COUNT(resd_id) as total_adult from mngresidents WHERE TIMESTAMPDIFF(YEAR, birth_date, CURDATE()) >= 18";
        $totaladultresult = mysqli_query($conn, query: $totaladult);
        $totaladults = mysqli_fetch_assoc($totaladultresult)['total_adult'] ?? 0;

        $totalpwd= "SELECT COUNT(resd_id) as total_pwd from mngresidents WHERE pwd = 'Yes'";
        $totalpwdresult = mysqli_query($conn, query: $totalpwd);
        $totalpwds = mysqli_fetch_assoc($totalpwdresult)['total_pwd'] ?? 0;

        $totalvoter= "SELECT COUNT(resd_id) as total_voter from mngresidents WHERE voters_status = 'Registered'";
        $totalvoterresult = mysqli_query($conn, query: $totalvoter);
        $totalvoters = mysqli_fetch_assoc($totalvoterresult)['total_voter'] ?? 0;
    ?>

<div class="d-flex">
    <div class="sidebar p-4 bg-primary">
        <img src="Systempics/barangay-labogon-mandaue-city-logo-png_seeklogo-528135.webp" alt="Barangay Logo">
        <p style="font-size: 30px; color: white;">Barangay Labogon</p>
        <div class="nav-items">
            <a href="dashboard.php" style="text-decoration: none; font-size: 1.2rem;" class="nav_link active">Dashboard</a><br><br>
            <a href="mngresidents.php" style="text-decoration: none; font-size: 1.2rem; color: white;" class="nav_link">Manage Residents</a><br><br>
            <a href="mngcomplaintsrequest.php" style="text-decoration: none; font-size: 1.2rem; color: white;" class="nav_link">Manage Complaints</a><br><br>
            <a href="#" style="text-decoration: none; font-size: 1.2rem; color: white;" class="nav_link">Manage Officials</a><br><br><br>
            <button class="btn btn-danger">Logout</button>
        </div>
    </div>

    <div class="main-content p-4 d-flex">
        <div class="content flex-grow-1">
            <h2 class="display-5 text-center">Welcome Admin!</h2>
            <h2 class="display-5 text-center">Barangay Labogon Information System</h2>
            <br><br><br>

            <div class="row text-center">

                <!-- Stat Box 1 -->

                <div class="col-md-4">
                    <div class="card  mb-3">
                        <div class="card-body">
                            <h4 class="card-title">Total Household</h4>
                            <h3 class="card-text display-4">
                            <?php echo $totalhouseholds; ?>
                            </h3>
                        </div>
                    </div>
                </div>

                <!-- Stat Box 2 -->

                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h4 class="card-title">Total Population</h4>
                            <h3 class="card-text display-4">
                            <?php echo $totalpopulations; ?>
                            </h3>
                        </div>
                    </div>
                </div>

                <!-- Stat Box 3 -->

                <div class="col-md-4">
                    <div class="card  mb-3">
                        <div class="card-body">
                            <h4 class="card-title">Male</h4>
                            <h3 class="card-text display-4">
                            <?php echo $totalmales; ?>
                            </h3>
                        </div>
                    </div>
                </div>

                <!-- Stat Box 4 -->

                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h4 class="card-title">Female</h4>
                            <h3 class="card-text display-4">
                            <?php echo $totalfemales; ?>
                            </h3>
                        </div>
                    </div>
                </div>

                <!-- Stat Box 5 -->

                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h4 class="card-title">Children</h4>
                            <h3 class="card-text display-4">
                            <?php echo $totalchildrens; ?>
                            </h3>
                        </div>
                    </div>
                </div>


                <!-- Stat Box 6 -->

                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h4 class="card-title">Senior</h4>
                            <h3 class="card-text display-4">
                            <?php echo $totalseniors; ?>
                            </h3>
                        </div>
                    </div>
                </div>

                <!-- Stat Box 7 -->

                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h4 class="card-title">Adult</h4>
                            <h3 class="card-text display-4">
                            <?php echo $totaladults; ?>
                            </h3>
                        </div>
                    </div>
                </div>

                <!-- Stat Box 8 -->

                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h4 class="card-title">PWD</h4>
                            <h3 class="card-text display-4">
                            <?php echo $totalpwds; ?>
                            </h3>
                        </div>
                    </div>
                </div>

                <!-- Stat Box 9 -->

                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h4 class="card-title">Voters</h4>
                            <h3 class="card-text display-4">
                            <?php echo $totalvoters; ?>
                            </h3>
                        </div>
                    </div>
                </div>

            </div>
        </div>

       <!-- Sidebar for Officials -->
<div class="officials-sidebar p-4 bg-light overflow-auto text-center" style="width: 300px; max-height: 100vh;">
    <h4>Barangay Officials</h4>
    
    <!-- Chairman -->
    <div class="official-card p-3 mb-3 bg-white rounded">
        <h5>Chairman</h5>
        <img src="officials_pics/chairman.jpg" alt="Chairman" style="width: 100%; height: auto; border-radius: 5px;">
        <p>John Doe</p>
    </div>
    
    <!-- Kagawad 1 -->
    <div class="official-card p-3 mb-3 bg-white rounded">
        <h5>Kagawad 1</h5>
        <img src="officials_pics/kagawad1.jpg" alt="Kagawad 1" style="width: 100%; height: auto; border-radius: 5px;">
        <p>Jane Smith</p>
    </div>
    
    <!-- Kagawad 2 -->
    <div class="official-card p-3 mb-3 bg-white rounded">
        <h5>Kagawad 2</h5>
        <img src="Systempics/sd.jpg" alt="Kagawad 2" style="width: 100%; height: auto; border-radius: 50%;">
        <p>Mark Johnson</p>
    </div>
    
</div>

    </div>
</div>

<script src="bootstrap-5.3.3-dist/js/bootstrap.min.js"></script>
<script src="active.js"></script>
</body>
</html>

<style>
    .d-flex {
        display: flex;
        height: 100vh;
    }

    .sidebar {
        width: 250px;
        text-align: center;
    }

    .main-content {
        flex-grow: 1;
        display: flex;
    }

    img {
        width: 100%;
    }

    .card-text {
        font-size: 2.5rem;
        font-weight: bold;
    }

    .active {
        background-color: darkblue;
        color: white; 
        border-radius: 5px; 
        padding: 5px; 
    }
    
    a:hover {
        background-color: darkblue;
        color: white; 
        border-radius: 5px; 
        padding: 5px; 
    }

    .officials-sidebar {
        overflow-y: auto;
    }

    .official-card img {
    width: 100%;
    height: auto;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

</style>
