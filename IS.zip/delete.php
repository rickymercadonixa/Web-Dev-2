<?php
    require 'connection.php';
?>
<?php

    $clear_id = isset($_GET['resd_id']) ? $_GET['resd_id'] : null;
    
    if(!$clear_id){
        die('No ID or Invalid ID');
    }

    $sql = "DELETE FROM mngresidents WHERE resd_id = '$clear_id'";
    $conn -> query($sql);

    header("Location: readresidents.php");
    exit();
?>