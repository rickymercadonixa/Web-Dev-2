<?php
    require 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Add Certificate</title>
</head>
<body>

<?php

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $resident_name = $_POST['resident_name'];
        $certificate_type = $_POST['certificate_type'];
        $date_issued = $_POST['date_issued'];
        $valid_until = $_POST['valid_until'];

                $sql = "INSERT INTO mngcertificate (resident_name, certificate_type, date_issued, valid_until)
                VALUES ('$resident_name', '$certificate_type', '$date_issued', '$valid_until')";

                if($conn->query($sql)){
                    header("Location: viewcertificate.php");
                    exit();
                }else{
                    echo "Error: ". $sql. "<br>" .$conn->error;
                }  
            }
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg">
                <div class="card-header bg-primary text-white text-center">
                    <h2>Add Certificate</h2>
                </div>
                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <!-- Resident Name -->
                        <div class="mb-3">
                            <label for="resident_name" class="form-label">Resident Name:</label>
                            <input type="text" class="form-control" id="resident_name" name="resident_name" required>
                        </div>
                        
                        <!-- Certificate Type -->
                        <div class="mb-3">
                            <label for="clerance_type" class="form-label">Certificate Type</label>
                            <input type="text" class="form-control" id="certificate_type" name="certificate_type" required>
                        </div>

                        <!-- Description -->
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
                        </div>

                        <!-- Date Filed -->
                        <div class="mb-3">
                            <label for="date_issued" class="form-label">Date Filed</label>
                            <input type="datetime-local" class="form-control" id="date_issued" name="date_issued" required>
                        </div>

                          <!-- Valid Until -->
                          <div class="mb-3">
                            <label for="valid_until" class="form-label">Valid Until</label>
                            <input type="datetime-local" class="form-control" id="valid_until" name="valid_until" required>
                        </div>

                        <!-- Submit Button -->
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-success">Add Certificate</button>
                            <a href="residentscertificate.php" class="btn btn-danger">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

