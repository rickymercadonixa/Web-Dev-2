<?php
    require 'connection.php';

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $clear_id = $_POST['resd_id'];

        $sql = "SELECT * FROM mngresidents WHERE resd_id = '$clear_id'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();

        $firstname = $_POST['firstname'];
        $middlename = $_POST['middlename'];
        $lastname = $_POST['lastname'];
        $nickname = $_POST['nickname'];
        $gender = $_POST['gender'];
        $birth_date = $_POST['birth_date'];
        $place_of_birth = $_POST['place_of_birth'];
        $civil_status = $_POST['civil_status'];
        $occupation = $_POST['occupation'];
        $religion = $_POST['religion'];
        $lot = $_POST['lot'];
        $purok = $_POST['purok'];
        $residents_status = $_POST['residents_status'];
        $voters_status = $_POST['voters_status'];
        $pwd = $_POST['pwd'];
        $email = $_POST['email'];
        $phone_number = $_POST['phone_number'];
        $telephone = $_POST['telephone'];

        if ($_FILES['photo']['size'] > 0) {
            $old_photo_path = $row['photo'];
            if (file_exists($old_photo_path)) {
                unlink($old_photo_path); 
            }

            $photo_path = 'photo/' . $_FILES['photo']['name'];
            if ($_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                move_uploaded_file($_FILES['photo']['tmp_name'], $photo_path);
            }

            $sql = "UPDATE mngresidents SET firstname = '$firstname', middlename = '$middlename', lastname = '$lastname', nickname = '$nickname', gender = '$gender', birth_date = '$birth_date', place_of_birth = '$place_of_birth', civil_status = '$civil_status', occupation = '$occupation', religion = '$religion', lot = '$lot', purok = '$purok', residents_status = '$residents_status', voters_status = '$voters_status', pwd = '$pwd', email = '$email', phone_number = '$phone_number', telephone = '$telephone', photo = '$photo_path' WHERE resd_id = '$clear_id'";
        } else {
            $sql = "UPDATE mngresidents SET firstname = '$firstname', middlename = '$middlename', lastname = '$lastname', nickname = '$nickname', gender = '$gender', birth_date = '$birth_date', place_of_birth = '$place_of_birth', civil_status = '$civil_status', occupation = '$occupation', religion = '$religion', lot = '$lot', purok = '$purok', residents_status = '$residents_status', voters_status = '$voters_status', pwd = '$pwd', email = '$email', phone_number = '$phone_number', telephone = '$telephone' WHERE resd_id = '$clear_id'";
        }

        if ($conn->query($sql) === TRUE) {
            header("Location: readresidents.php");
            exit();
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }

    $clear_id = isset($_GET['resd_id']) ? $_GET['resd_id'] : null;

    if (!$clear_id) {
        die('No ID or Invalid ID');
    }

    $sql = "SELECT * FROM mngresidents WHERE resd_id = $clear_id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Update Resident</title>
</head>
<body>
<div class="form-container">
        <h1>Update Resident Information</h1>

        <form action="" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="resd_id" value="<?php echo $row['resd_id']; ?>">

            <div class="mb-3">
                <label for="firstname" class="form-label">First Name:</label>
                <input type="text" class="form-control" name="firstname" id="firstname" value="<?php echo $row['firstname']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="middlename" class="form-label">Middle Name:</label>
                <input type="text" class="form-control" name="middlename" id="middlename" value="<?php echo $row['middlename']; ?>">
            </div>

            <div class="mb-3">
                <label for="lastname" class="form-label">Last Name:</label>
                <input type="text" class="form-control" name="lastname" id="lastname" value="<?php echo $row['lastname']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="nickname" class="form-label">Nickname:</label>
                <input type="text" class="form-control" name="nickname" id="nickname" value="<?php echo $row['nickname']; ?>">
            </div>

            <div class="mb-3">
                <label for="gender" class="form-label">Gender:</label>
                <select class="form-select" name="gender" id="gender" required>
                    <option value="Male" <?php if($row['gender'] == 'Male') echo 'selected'; ?>>Male</option>
                    <option value="Female" <?php if($row['gender'] == 'Female') echo 'selected'; ?>>Female</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="birth_date" class="form-label">Birth Date:</label>
                <input type="date" class="form-control" name="birth_date" id="birth_date" value="<?php echo $row['birth_date']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="place_of_birth" class="form-label">Place of Birth:</label>
                <input type="text" class="form-control" name="place_of_birth" id="place_of_birth" value="<?php echo $row['place_of_birth']; ?>">
            </div>

            <div class="mb-3">
                <label for="civil_status" class="form-label">Civil Status:</label>
                <select class="form-select" name="civil_status" id="civil_status">
                    <option value="Single" <?php if($row['civil_status'] == 'Single') echo 'selected'; ?>>Single</option>
                    <option value="Married" <?php if($row['civil_status'] == 'Married') echo 'selected'; ?>>Married</option>
                    <option value="Widowed" <?php if($row['civil_status'] == 'Widowed') echo 'selected'; ?>>Widowed</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="occupation" class="form-label">Occupation:</label>
                <input type="text" class="form-control" name="occupation" id="occupation" value="<?php echo $row['occupation']; ?>">
            </div>

            <div class="mb-3">
                <label for="religion" class="form-label">Religion:</label>
                <input type="text" class="form-control" name="religion" id="religion" value="<?php echo $row['religion']; ?>">
            </div>

            <div class="mb-3">
                <label for="lot" class="form-label">Lot:</label>
                <input type="text" class="form-control" name="lot" id="lot" value="<?php echo $row['lot']; ?>">
            </div>

            <div class="mb-3">
                <label for="purok" class="form-label">Purok:</label>
                <input type="text" class="form-control" name="purok" id="purok" value="<?php echo $row['purok']; ?>">
            </div>

            <div class="mb-3">
                <label for="residents_status" class="form-label">Resident Status:</label>
                <input type="text" class="form-control" name="residents_status" id="residents_status" value="<?php echo $row['residents_status']; ?>">
            </div>

            <div class="mb-3">
                <label for="voters_status" class="form-label">Voter Status:</label>
                <input type="text" class="form-control" name="voters_status" id="voters_status" value="<?php echo $row['voters_status']; ?>">
            </div>

            <div class="mb-3">
                <label for="pwd" class="form-label">PWD (Person with Disability):</label>
                <select class="form-select" name="pwd" id="pwd">
                    <option value="Yes" <?php if($row['pwd'] == 'Yes') echo 'selected'; ?>>Yes</option>
                    <option value="No" <?php if($row['pwd'] == 'No') echo 'selected'; ?>>No</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email:</label>
                <input type="email" class="form-control" name="email" id="email" value="<?php echo $row['email']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="phone_number" class="form-label">Phone Number:</label>
                <input type="text" class="form-control" name="phone_number" id="phone_number" value="<?php echo $row['phone_number']; ?>">
            </div>

            <div class="mb-3">
                <label for="telephone" class="form-label">Telephone:</label>
                <input type="text" class="form-control" name="telephone" id="telephone" value="<?php echo $row['telephone']; ?>">
            </div>

            <div class="mb-3">
                <label for="photo" class="form-label">Photo:</label>
                <input type="file" class="form-control" name="photo" id="photo">
                <img src="<?php echo $row['photo']; ?>" alt="Current Photo" class="img-fluid">
            </div>

            <button type="submit" class="btn btn-primary">Update Resident</button><br><br>
            <a href="mngresidents.php" class="btn btn-danger col-md-12">Back</a>
        </form>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .form-container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-control {
            margin-bottom: 15px;
        }

        .btn-primary {
            width: 100%;
        }

        img {
            display: block;
            margin: 10px auto;
            width: 150px;
            height: auto;
            border-radius: 50%;
        }
    </style>
