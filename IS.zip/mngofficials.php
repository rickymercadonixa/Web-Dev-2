<?php
    require 'connection.php';
    
    $sql = "SELECT * FROM mngofficials";
    $result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Manage Officials</title>
</head>
<body>
    
<div class="d-flex">
    <div class="sidebar p-4 bg-primary">
        <img src="Systempics/barangay-labogon-mandaue-city-logo-png_seeklogo-528135.webp" alt="Barangay Logo">
        <p style="font-size: 30px; color: white;">Barangay Labogon</p>
        <div class="nav-items">
            <a href="dashboard.php" style="text-decoration: none; font-size: 1.2rem; color: white;" class="nav_link ">Dashboard</a><br><br>
            <a href="mngresidents.php" style="text-decoration: none; font-size: 1.2rem; color: white;" class="nav_link">Manage Residents</a><br><br>
            <a href="mngcomplaintsrequest.php" style="text-decoration: none; font-size: 1.2rem; color: white;" class="nav_link">Manage Community Tax</a><br><br>
            <a href="mngofficials.php" style="text-decoration: none; font-size: 1.2rem; color: white;" class="nav_link active">Manage Officials</a><br><br><br>
            <button class="btn btn-danger">Logout</button>
        </div>
    </div>

    <div class="main-content p-4"><br><br>
        <h2>Manage Officials</h2>
        <p>This is where you can manage barangay officials.</p>
        <a href="mngcomplaintsrequest.php" class="btn btn-danger">Back</a>
        <a href="addofficials.php"  class="card-text btn btn-primary">Add Officials</a>
<br><br>

<div class="container">
    <h1>Manage Officials</h1>
    <div class="officials-list">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "
                <div class='official-card'>
                    <img src='" . $row['photo'] . "' alt='Profile Picture'>
                    <h3>" . $row['name'] . "</h3>
                    <p>Position: " . $row['position'] . "</p>
                    <a href='viewprofile.php?official_id=" . $row['official_id'] . "' class='btn'>View Profile</a>
                </div>";
            }
        } else {
            echo "No officials found.";
        }
        ?>
    </div>
</div>
</div>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.min.js"></script>
</body>
</html>

<style>
    .d-flex {
        display: flex;
        height: 100vh;
    }

    .sidebar {
        width: 250px;
        text-align: center;
    }

    .main-content {
        flex-grow: 1;
    }

    img {
        width: 100%;
    }


    .active {
    background-color: darkblue;
    color: white; 
    border-radius: 5px; 
    padding: 5px; 
    }

    a:hover{
    background-color: darkblue;
    color: white; 
    border-radius: 5px; 
    padding: 5px; 
    }

    body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    margin-bottom: 20px;
}

.officials-list {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
}

.official-card {
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
    margin: 10px;
    width: 250px;
    text-align: center;
    transition: transform 0.2s;
}

.official-card img {
    border-radius: 50%;
    width: 100px;
    height: 100px;
    object-fit: cover;
}

.official-card h3 {
    font-size: 18px;
    margin: 10px 0;
}

.official-card p {
    margin: 5px 0;
    color: #555;
}

.official-card a {
    display: inline-block;
    padding: 10px 20px;
    background-color: #f0a500;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    margin-top: 10px;
}

.official-card:hover {
    transform: translateY(-10px);
}

</style>
