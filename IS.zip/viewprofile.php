<?php
require 'connection.php';

// Check if official_id is set in the GET request
if (!isset($_GET['official_id'])) {
    echo "Official ID not provided.";
    exit();
}

$id = (int)$_GET['official_id'];  // Typecast for safety

$sql = "SELECT * FROM mngofficials WHERE official_id = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Official not found";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($row['name']); ?>'s Profile</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
<a href="mngofficials.php" class="btn btn-danger">Back</a>
<div class="container">
    <!-- Display official's photo -->
    <div class="official-image">
        <img src="<?php echo htmlspecialchars($row['photo']); ?>" alt="Profile Picture of <?php echo htmlspecialchars($row['name']); ?>" width="150" height="150">
    </div>

    <!-- Display official's profile details -->
    <h1><?php echo htmlspecialchars($row['name']); ?>'s Profile</h1>
    <p><strong>Birthdate:</strong> <?php echo htmlspecialchars($row['birthdate']); ?></p>
    <p><strong>Position:</strong> <?php echo htmlspecialchars($row['position']); ?></p>
    <a href='updateprofile.php?official_id=<?php echo $row['official_id']; ?>' class='btn btn-info btn-sm'>Update</a>
    <a href='deleteprofile.php?official_id=<?php echo $row['official_id']; ?>' class='btn btn-danger btn-sm'>Delete</a>

</div>

</body>
</html>

<style>
/* Reset some basic styles */
body, h1, p {
    margin: 0;
    padding: 0;
}

/* Body styling */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    color: #333;
}

/* Container for profile content */
.container {
    max-width: 600px;
    margin: 50px auto;
    padding: 20px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    text-align: center;
}

/* Profile picture styling */
.official-image img {
    border-radius: 50%;
    margin-bottom: 20px;
}

/* Headings and text */
h1 {
    font-size: 28px;
    color: #333;
    margin-bottom: 10px;
}

p {
    font-size: 18px;
    color: #555;
    margin-bottom: 8px;
}

p strong {
    color: #222;
}
</style>
