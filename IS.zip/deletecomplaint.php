<?php
    require 'connection.php';
?>
<?php

    $clear_id = isset($_GET['comp_id']) ? $_GET['comp_id'] : null;
    
    if(!$clear_id){
        die('No ID or Invalid ID');
    }

    $sql = "DELETE FROM mngcomplaints WHERE comp_id = '$clear_id'";
    $conn -> query($sql);

    header("Location: residentscomplaints.php");
    exit();
?>