<?php
require 'connection.php';

if (isset($_GET['id'])) {
    $student_id = $_GET['id'];

    // Fetch the student data to confirm deletion
    $query = "SELECT * FROM students WHERE student_number = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();

    if (!$student) {
        echo "Student not found.";
        exit();
    }

    // If the form is submitted to confirm deletion
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $delete_query = "DELETE FROM students WHERE student_number = ?";
        $delete_stmt = $conn->prepare($delete_query);
        $delete_stmt->bind_param("s", $student_id);

        if ($delete_stmt->execute()) {
            header("Location: viewall_students.php"); // Redirect back to the student list page
            exit();
        } else {
            echo "Error deleting record.";
        }
    }
} else {
    echo "No student selected.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Student</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Delete Student</h2>
    <p>Are you sure you want to delete the following student?</p>
    <ul>
        <li>Student Number: <?= htmlspecialchars($student['student_number']) ?></li>
        <li>Name: <?= htmlspecialchars($student['student_name']) ?></li>
        <li>Guardian Name: <?= htmlspecialchars($student['guardian_name']) ?></li>
        <!-- Add any other necessary student information -->
    </ul>
    <form method="POST">
        <button type="submit" class="btn btn-danger">Confirm Deletion</button>
        <a href="viewall_students.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>
