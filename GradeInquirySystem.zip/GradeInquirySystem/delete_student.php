<?php
require 'connection.php';

if (isset($_GET['id'])) {
    $student_id = $_GET['id'];

    $query = "SELECT * FROM students WHERE student_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();

    if (!$student) {
        
        echo "Student not found.";
        exit();
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $delete_query1 = "DELETE FROM students WHERE student_id = ?";
        $delete_stmt1 = $conn->prepare($delete_query1);
        $delete_stmt1->bind_param("s", $student_id);
    
        if ($delete_stmt1->execute()) {
            header("Location: viewall_students.php");
            exit();
        } else {
            echo "Error deleting record.";
        }
    }
}    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Student</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Delete Student</h2>
    <p>Are you sure you want to delete the following student?</p>
    <ul>
        <li>Student ID: <?= htmlspecialchars($student['student_id']) ?></li>
        <li>Name: <?= htmlspecialchars($student['student_name']) ?></li>
        <li>Guardian Name: <?= htmlspecialchars($student['guardian_name']) ?></li>
    </ul>
    <form method="POST">
        <button type="submit" class="btn btn-danger">Confirm Deletion</button>
        <a href="viewall_students.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>
