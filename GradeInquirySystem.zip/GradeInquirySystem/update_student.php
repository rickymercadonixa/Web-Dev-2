<?php
require 'connection.php';

if (isset($_GET['id'])) {
    $student_id = $_GET['id'];

    // Fetch the student data from the database
    $query = "SELECT 
                students.student_number,
                students.student_name,
                students.date_of_birth,
                students.guardian_name,
                students.guardian_contact,
                students.date_enrolled,
                students.photo,
                classes.class_id
              FROM students
              JOIN classes ON students.class_id = classes.class_id
              WHERE student_number = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();

    if (!$student) {
        echo "Student not found.";
        exit();
    }
} else {
    echo "No student selected.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_name = $_POST['student_name'];
    $date_of_birth = $_POST['date_of_birth'];
    $guardian_name = $_POST['guardian_name'];
    $guardian_contact = $_POST['guardian_contact'];
    $class_id = $_POST['class_id'];

    // Update student data in the database
    $update_query = "UPDATE students SET 
                        student_name = ?,
                        date_of_birth = ?,
                        guardian_name = ?,
                        guardian_contact = ?,
                        class_id = ?
                     WHERE student_number = ?";
    
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("ssssss", $student_name, $date_of_birth, $guardian_name, $guardian_contact, $class_id, $student_id);

    if ($update_stmt->execute()) {
        header("Location: viewall_students.php"); // Redirect back to the student list page
        exit();
    } else {
        echo "Error updating record.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Student</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Update Student Information</h2>
    <form method="POST">
        <div class="mb-3">
            <label for="student_name" class="form-label">Student Name</label>
            <input type="text" class="form-control" id="student_name" name="student_name" value="<?= htmlspecialchars($student['student_name']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="date_of_birth" class="form-label">Date of Birth</label>
            <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" value="<?= htmlspecialchars($student['date_of_birth']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="guardian_name" class="form-label">Guardian Name</label>
            <input type="text" class="form-control" id="guardian_name" name="guardian_name" value="<?= htmlspecialchars($student['guardian_name']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="guardian_contact" class="form-label">Guardian Contact</label>
            <input type="text" class="form-control" id="guardian_contact" name="guardian_contact" value="<?= htmlspecialchars($student['guardian_contact']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="class_id" class="form-label">Class</label>
            <select class="form-control" id="class_id" name="class_id" required>
                <?php
                $class_query = "SELECT class_id, class_name FROM classes";
                $class_result = $conn->query($class_query);
                while ($class = $class_result->fetch_assoc()) {
                    $selected = ($class['class_id'] == $student['class_id']) ? "selected" : "";
                    echo "<option value='" . $class['class_id'] . "' $selected>" . htmlspecialchars($class['class_name']) . "</option>";
                }
                ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="viewall_students.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>
