<?php
require 'connection.php';
$message = "";
$teacher_id = $_SESSION['teacher_id'] ?? 0;

$student_query = "
    SELECT students.student_id, students.student_name 
    FROM students 
    JOIN classes ON students.class_id = classes.class_id 
    WHERE classes.teacher_id = ?
";
$stmt = $conn->prepare($student_query);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$students_result = $stmt->get_result();

$subjects = $conn->query("SELECT subject_id, subject_name FROM subjects");

$teachers = $conn->query("SELECT teacher_id, teacher_name FROM teachers");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student_id'];
    $subject_id = $_POST['subject_id'];
    $grade = $_POST['grade'];
    $description = $_POST['description'];
    $date_recorded = $_POST['date_recorded'];
    $teacher_id = $_POST['teacher_id'];

    $grade_query = "INSERT INTO grades (student_id, subject_id, grade, description, date_recorded, teacher_id) VALUES (?, ?, ?, ?, ?, ?)";
    $grade_stmt = $conn->prepare($grade_query);
    $grade_stmt->bind_param("iisssi", $student_id, $subject_id, $grade, $description, $date_recorded, $teacher_id);

    if ($grade_stmt->execute()) {
        $message = '<p class="text-success">Grade successfully added.</p>';
    } else {
        $message = '<p class="text-danger">Error adding grade.</p>';
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Teacher Dashboard - Add Students</title>
    <style>
        body {
            display: flex;
            min-height: 100vh;
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            background-color: #004d99;
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: white;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }

        .sidebar-header img {
            width: 90px;
            height: 90px;
        }

        .sidebar-header p {
            font-size: 1.2rem;
            color: #ffffff;
        }

        .nav-items a {
            display: block;
            text-decoration: none;
            font-size: 1.1rem;
            color: #ffffff;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            transition: background-color 0.3s;
            text-align: center;
        }

        .nav-items a.active,
        .nav-items a:hover {
            background-color: #003366;
        }

        .btn-logout {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn-logout:hover {
            background-color: #c0392b;
        }

        /* Main content styling */
        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #fff;
        }

        .main-content h1 {
            font-size: 2rem;
            color: #333;
            margin-bottom: 20px;
        }

        .main-content p {
            font-size: 1.1rem;
            color: #555;
            line-height: 1.6;
        }

        .form-section {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .form-section h4 {
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .form-section input,
        .form-section select,
        .form-section textarea {
            margin-bottom: 15px;
        }

        .caret-icon {
            transition: transform 0.3s;
        }
    </style>
</head>

<body>
    <div class="sidebar">

        <div class="sidebar-header">
            <img src="a-removebg-preview.png" alt="School Logo">
            <p>CEBUANO ELEMENTARY SCHOOL</p>
        </div>

        <div class="nav-items">
            <a href="teacher_dashboard.php" class="nav_link">Dashboard</a>
            <a href="teacher_addstudents.php" class="nav_link">Add Students</a>
            <a href="teacher_addgrades.php" class="nav_link">Grades</a>
            <a href="notify.php" class="nav_link">Notification</a>
        </div>

        <a href="teacher_logout.php" class="btn-logout">Logout</a>
    </div>

    <div class="main-content">
        <h2>Add Grade</h2>
        <?php echo $message; ?>
        <form method="POST" class="form-section">
            <div class="row">

                <div class="col-md-6">
                    <label for="student_id" class="form-label">Student Name</label>
                    <select name="student_id" id="student_id" class="form-control" required>
                        <option value="" disabled selected>Select Student</option>
                        <?php while ($student = $students_result->fetch_assoc()) { ?>
                            <option value="<?php echo $student['student_id']; ?>"><?php echo $student['student_name']; ?></option>
                        <?php } ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label for="subject_id" class="form-label">Subject Name (<a href="teacher_addsubject.php">Add Subject First</a>)</label>
                    <select name="subject_id" id="subject_id" class="form-control" required>
                        <option value="" disabled selected>Select Subject</option>
                        <?php while ($subject = $subjects->fetch_assoc()) { ?>
                            <option value="<?php echo $subject['subject_id']; ?>"><?php echo $subject['subject_name']; ?></option>
                        <?php } ?>

                    </select>

                </div>

                <div class="col-md-6">
                    <label for="grade" class="form-label">Grade</label>
                    <input type="number" step="0.1" name="grade" class="form-control" id="grade" placeholder="Enter Grade" required>
                </div>

                <div class="col-md-6">
                    <label for="description" class="form-label">Description</label>
                    <input type="text" name="description" class="form-control" id="grade" placeholder="Enter Description" required>
                </div>

                <div class="col-md-6">
                    <label for="date_recorded" class="form-label">Date recorded</label>
                    <input type="date" name="date_recorded" class="form-control" id="grade" required>
                </div>

                <div class="col-md-6">
                    <label for="teacherId" class="form-label">Teacher Name</label>
                    <select name="teacher_id" id="teacherId" class="form-control" required>
                        <option value="" disabled selected>Select Teacher</option>
                        <?php while ($teacher = $teachers->fetch_assoc()) { ?>
                            <option value="<?php echo $teacher['teacher_id']; ?>"><?php echo $teacher['teacher_name']; ?></option>
                        <?php } ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary mt-4">Add Grade</button>
            </div>
        </form>
    </div>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>