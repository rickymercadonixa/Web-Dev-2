<?php
require 'connection.php';

$sql = "
    SELECT students.student_number, students.student_name, students.date_of_birth, students.guardian_name,
           students.guardian_contact, students.date_enrolled, students.photo, classes.class_name, teachers.teacher_name
    FROM students
    JOIN classes ON students.class_id = classes.class_id
    JOIN teachers ON classes.teacher_id = teachers.teacher_id
";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Student Records</title>
</head>

<body>
    <div class="container mt-5">
        <h2 class="mb-4">Student Records</h2>
        
        <?php if ($result->num_rows > 0): ?>
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>Student Number</th>
                        <th>Student Name</th>
                        <th>Date of Birth</th>
                        <th>Guardian Name</th>
                        <th>Guardian Contact</th>
                        <th>Date Enrolled</th>
                        <th>Class Name</th>
                        <th>Teacher Name</th>
                        <th>Photo</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['student_number']); ?></td>
                            <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['date_of_birth']); ?></td>
                            <td><?php echo htmlspecialchars($row['guardian_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['guardian_contact']); ?></td>
                            <td><?php echo htmlspecialchars($row['date_enrolled']); ?></td>
                            <td><?php echo htmlspecialchars($row['class_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['teacher_name']); ?></td>
                            <td>
                                <img src="<?php echo htmlspecialchars($row['photo']); ?>" alt="Student Photo" width="50" height="50">
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No records found.</p>
        <?php endif; ?>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<style>
        body {
            display: flex;
            min-height: 100vh;
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            background-color: #004d99;
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: white;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }

        .sidebar-header img {
            width: 90px;
            height: 90px;
        }

        .sidebar-header p {
            font-size: 1.2rem;
            color: #ffffff;
        }

        .nav-items a {
            display: block;
            text-decoration: none;
            font-size: 1.1rem;
            color: #ffffff;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            transition: background-color 0.3s;
            text-align: center;
        }

        .nav-items a.active,
        .nav-items a:hover {
            background-color: #003366;
        }

        .btn-logout {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn-logout:hover {
            background-color: #c0392b;
        }

        /* Main content styling */
        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #fff;
        }

        .main-content h1 {
            font-size: 2rem;
            color: #333;
            margin-bottom: 20px;
        }

        .main-content p {
            font-size: 1.1rem;
            color: #555;
            line-height: 1.6;
        }

        .form-section {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .form-section h4 {
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .form-section input,
        .form-section select,
        .form-section textarea {
            margin-bottom: 15px;
        }
</style>
