<?php
require 'connection.php';

$students = $conn->query("SELECT student_id, student_name FROM students");
$teachers = $conn->query("SELECT teacher_id, teacher_name FROM teachers");

$message = '';

if (isset($_POST['submit'])) {
    $user = $_POST['user'];
    $pass = $_POST['pass'];
    $role = $_POST['role'];
    $guardian_id = !empty($_POST['guardian_id']) ? $_POST['guardian_id'] : null;
    $teacher_id = !empty($_POST['teacher_id']) ? $_POST['teacher_id'] : null;

    $query = "SELECT * FROM `users` WHERE `username` = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if (strlen($user) < 8 || strlen($pass) < 8) {
        $message = '<p class="text-danger">Username and Password must be at least 8 characters long!</p>';
    } elseif ($row) {
        $message = '<p class="text-danger">User already exists! Please try another username!</p>';
    } else {
        $hashedPass = password_hash($pass, PASSWORD_DEFAULT);

        $sql = "INSERT INTO `users` (`username`, `password`, `user_role`, `guardian_id`, `teacher_id`) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $user, $hashedPass, $role, $guardian_id, $teacher_id);

        if ($stmt->execute()) {
            echo '<script>alert("Registered Successfully!"); window.location.href = "admin_dashboard.php"; </script>';
        } else {
            $message = '<p class="text-danger">Failed to register. Please try again later.</p>';
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration Page - Grade Inquiry System</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script>
        function toggleFields() {
            const role = document.getElementById('role').value;
            document.getElementById('studentFields').style.display = role === 'Student' || role === 'Guardian' ? 'block' : 'none';
            document.getElementById('teacherFields').style.display = role === 'Teacher' ? 'block' : 'none';
        }
    </script>
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white text-center">
                    <h4>Register - as a Guardian, Student, or Teacher</h4>
                </div>
                <div class="card-body">
                    <?php echo $message; ?>
                    <form method="post">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" name="user" id="username" class="form-control" placeholder="Username" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" name="pass" id="password" class="form-control" placeholder="Password" required>
                        </div>
                        <div class="mb-3">
                            <label for="role" class="form-label">User Role</label>
                            <select id="role" name="role" class="form-select" onchange="toggleFields()" required>
                                <option value="">Select Role</option>
                                <option value="Student">Student</option>
                                <option value="Teacher">Teacher</option>
                                <option value="Guardian">Guardian</option>
                            </select>
                        </div>

                        <!-- Student and Guardian Fields -->
                        <div id="studentFields" style="display: none;">
                            <div class="mb-3">
                                <label for="guardianId" class="form-label">Select Student <span class="text-danger">(required only for Guardians and Students)</span></label>
                                <select name="guardian_id" id="guardianId" class="form-select">
                                    <option value="">None</option>
                                    <?php while ($student = $students->fetch_assoc()) { ?>
                                        <option value="<?php echo $student['student_id']; ?>">
                                            <?php echo htmlspecialchars($student['student_name']); ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <!-- Teacher Fields -->
                        <div id="teacherFields" style="display: none;">
                            <div class="mb-3">
                                <label for="teacherId" class="form-label">Select Teacher <span class="text-danger">(required only for Teachers)</span></label>
                                <select name="teacher_id" id="teacherId" class="form-select">
                                    <option value="">None</option>
                                    <?php while ($teacher = $teachers->fetch_assoc()) { ?>
                                        <option value="<?php echo $teacher['teacher_id']; ?>">
                                            <?php echo htmlspecialchars($teacher['teacher_name']); ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <button type="submit" name="submit" class="btn btn-primary w-100">Register</button>
                        <a href="students.php" class="btn btn-danger col-md-12">Back</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>

<style>
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f5f5f5;
    }
    .card {
        border: none;
        border-radius: 10px;
    }
    .card-header {
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }
</style>
