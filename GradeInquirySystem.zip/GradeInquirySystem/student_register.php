<?php
require 'connection.php';

$message = '';

if (isset($_POST['submit'])) {
  $user = $_POST['user'];
  $pass = $_POST['pass'];
  $role = $_POST['role'];

  // Check if username is already taken
  $query = "SELECT * FROM `users` WHERE `username` = ?";
  $stmts = $conn->prepare($query);
  $stmts->bind_param("s", $user);
  $stmts->execute();
  $result = $stmts->get_result();
  $row = $result->fetch_assoc();

  // Validate username and password length
  if (strlen($user) < 8 || strlen($pass) < 8) {
    $message = '<p class="text-danger">Username and Password must be at least 8 characters long!</p>';
  } elseif ($row) {
    $message = '<p class="text-danger">User already exists! Please try another username!</p>';
  } else {
    // Hash the password
    $hashedPass = password_hash($pass, PASSWORD_DEFAULT);

    // Prepare the insertion query
    $sql = "INSERT INTO `users` (`username`, `password`, `user_role`) VALUES (?, ?, ?)";

    // Check if role was selected properly
    if ($role) {
      $stmt = $conn->prepare($sql);

      // Bind parameters (username, password, role)
      $stmt->bind_param("sss", $user, $hashedPass, $role);

      // Execute the query
      if ($stmt->execute()) {
        echo '<script>alert("Register Successfully!"); window.location.href = "login.php"; </script>';
      } else {
        $message = '<p class="text-danger">Failed to register. Please try again later.</p>';
      }

    } else {
      $message = '<p class="text-danger">Please select a role before submitting.</p>';
    }
  }
}
?>



<!DOCTYPE html>
<html>
<head>
  <title>Registration Page</title>
  <link rel="stylesheet" type="text/css" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
  <div class="login-page">
    <div class="form">
      
      <h2>Register</h2>
      <?php echo $message; ?>
      <form  method="post" class="login-form">
  <input type="text" name="user" placeholder="Username" required="">
  <input type="password" name="pass" placeholder="Password" id="pass" required="">
  <select id="role" name="role" class="form-select" required>
                    <option value="">Select Role</option>
                    <option value="Student">Student</option>
                    <option value="Teacher">Teacher</option>
                    <option value="Guardian">Guardian</option>
                </select><br>
  <button type="submit" name="submit">Register</button>
</form>
<br>
<p>Already registered? <a href="login.php">Login here</a>.</p>
    </div>
  </div>
</body>
</html>


<style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      padding: 0;
      font-family: sans-serif;
      background-image: linear-gradient(to right, #667eea, #764ba2);
    }

    .login-page {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .form {
      background: #fff;
      max-width: 360px;
      width: 100%;
      padding: 50px 40px;
      border-radius: 10px;
      box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.1);
    }

    .form h2 {
      margin-bottom: 20px;
      color: #333;
      text-align: center;
    }

    .form input {
      border-radius: 5px;
      border: none;
      background: #f0f0f0;
      padding: 10px;
      margin-bottom: 20px;
      width: 100%;
      font-size: 14px;
      color: #333;
    }

    .form input:focus {
      outline: none;
      background: #e6e6e6;
    }

    .form button {
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
      padding: 10px;
      width: 100%;
      transition: all 0.2s ease;
      margin-top: 10px;
    }

    .form button:hover {
      background-color: #3e8e41;
    }
</style>
