<?php
require 'connection.php';

if (isset($_GET['id'])) {
    $student_id = $_GET['id'];

    // Fetch the student data
    $query = "SELECT student_number, student_name FROM students WHERE student_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $student_number = $_POST['student_number'];
        $student_name = $_POST['student_name'];

        // Update student data
        $update_query = "UPDATE students SET student_number = ?, student_name = ? WHERE student_id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("ssi", $student_number, $student_name, $student_id);

        if ($stmt->execute()) {
            header("Location: teacher_dashboard.php");
            exit();
        } else {
            echo "Error updating record.";
        }
    }
} else {
    echo "Invalid request.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Student</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            max-width: 400px;
            width: 100%;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 1.5em;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #007BFF;
            color: white;
            font-size: 1em;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
        .back-button {
            display: block;
            text-align: center;
            margin-top: 15px;
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
            transition: color 0.3s;
        }
        .back-button:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Update Student</h2>
        <form method="POST">
            <label for="student_number">Student Number:</label>
            <input type="text" id="student_number" name="student_number" value="<?= htmlspecialchars($student['student_number']) ?>" required>
            
            <label for="student_name">Student Name:</label>
            <input type="text" id="student_name" name="student_name" value="<?= htmlspecialchars($student['student_name']) ?>" required>
            
            <button type="submit">Update</button>
        </form>
        <a href="teacher_dashboard.php" class="back-button">Back to Dashboard</a>
    </div>
</body>
</html>
