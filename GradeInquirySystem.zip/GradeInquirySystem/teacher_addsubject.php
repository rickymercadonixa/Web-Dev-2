<?php
require 'connection.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject_name = $_POST['subject_name'];

    $subject_query = "INSERT INTO subjects (subject_name) VALUES (?)";
    $subject_stmt = $conn->prepare($subject_query);
    $subject_stmt->bind_param("s", $subject_name);

    if ($subject_stmt->execute()) {
        $message = '<p class="text-success">Subject successfully added.</p>';
    } else {
        $message = '<p class="text-danger">Error adding subject.</p>';
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Teacher Dashboard - Add Subject</title>
    <style>
        body {
            display: flex;
            min-height: 100vh;
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            background-color: #004d99;
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: white;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }

        .sidebar-header img {
            width: 90px;
            height: 90px;
        }

        .sidebar-header p {
            font-size: 1.2rem;
            color: #ffffff;
        }

        .nav-items a {
            display: block;
            text-decoration: none;
            font-size: 1.1rem;
            color: #ffffff;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            transition: background-color 0.3s;
            text-align: center;
        }

        .nav-items a.active,
        .nav-items a:hover {
            background-color: #003366;
        }

        .btn-logout {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn-logout:hover {
            background-color: #c0392b;
        }

        /* Main content styling */
        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #fff;
        }

        .main-content h1 {
            font-size: 2rem;
            color: #333;
            margin-bottom: 20px;
        }

        .main-content p {
            font-size: 1.1rem;
            color: #555;
            line-height: 1.6;
        }

        .form-section {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .form-section h4 {
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .form-section input,
        .form-section select,
        .form-section textarea {
            margin-bottom: 15px;
        }

        .caret-icon {
            transition: transform 0.3s;
        }
    </style>
</head>

<body>
    <div class="sidebar">

        <div class="sidebar-header">
            <img src="a-removebg-preview.png" alt="School Logo">
            <p>CEBUANO ELEMENTARY SCHOOL</p>
        </div>

        <div class="nav-items">
            <a href="teacher_dashboard.php" class="nav_link">Dashboard</a>
            <a href="teacher_addstudents.php" class="nav_link">Add Students</a>
            <a href="teacher_addgrades.php" class="nav_link">Grades</a>
        </div>

        <a href="teacher_logout.php" class="btn-logout">Logout</a>
    </div>

    <div class="main-content">
        <h2>Add Grade</h2>
        <?php echo $message; ?>
        <form method="POST" class="form-section">
            <div class="row">

                <div class="col-md-6">
                    <label for="subject_id" class="form-label">Subject Name</label>
                    <input type="text" class="form-control" name="subject_name">
                </div>


                <button type="submit" class="btn btn-primary mt-4 mb-2">Add Subject</button>
                <a href="teacher_addgrades.php" class="btn btn-danger">Back</a>
            </div>
        </form>
    </div>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>