<?php
require 'connection.php';

$message = "";

$classes = $conn->query("SELECT class_id, class_name FROM classes");
$teachers = $conn->query("SELECT teacher_id, teacher_name FROM teachers");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_number = $_POST['student_number'];
    $student_name = $_POST['student_name'];
    $date_of_birth = $_POST['date_of_birth'];
    $guardian_name = $_POST['guardian_name'];
    $guardian_contact = $_POST['guardian_contact'];
    $date_enrolled = $_POST['date_enrolled'];
    $class_id = $_POST['class_id'];
    $teacher_id = $_POST['teacher_id'];

    if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == 0) {
        $photo_name = $_FILES['photo']['name'];
        $photo_tmp = $_FILES['photo']['tmp_name'];
        $photo_path = 'studentphoto/' . $photo_name;

        if (move_uploaded_file($photo_tmp, $photo_path)) {
            $conn->begin_transaction();

            try {
                $student_query = "INSERT INTO students (student_number, student_name, date_of_birth, guardian_name, guardian_contact, date_enrolled, photo, class_id)
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $student_stmt = $conn->prepare($student_query);
                $student_stmt->bind_param("sssssssi", $student_number, $student_name, $date_of_birth, $guardian_name, $guardian_contact, $date_enrolled, $photo_path, $class_id);
                $student_stmt->execute();

                $conn->commit();
                $message = '<p class="text-success"> Student successfully added with class and teacher.</p>';
            } catch (Exception $e) {
                $conn->rollback();
                $message = '<p class="text-danger"> Failed to insert data: ' . $e->getMessage() . '</p>';
            }
        } else {
            $message = '<p class="text-danger"> Error uploading file.</p>';
        }
    } else {
        $message = '<p class="text-danger"> No file uploaded. Please try again.</p>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Teacher Dashboard - Add Students</title>
    <style>
        body {
            display: flex;
            min-height: 100vh;
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            background-color: #004d99;
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: white;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }

        .sidebar-header img {
            width: 90px;
            height: 90px;
        }

        .sidebar-header p {
            font-size: 1.2rem;
            color: #ffffff;
        }

        .nav-items a {
            display: block;
            text-decoration: none;
            font-size: 1.1rem;
            color: #ffffff;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            transition: background-color 0.3s;
            text-align: center;
        }

        .nav-items a.active,
        .nav-items a:hover {
            background-color: #003366;
        }

        .btn-logout {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn-logout:hover {
            background-color: #c0392b;
        }

        /* Main content styling */
        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #fff;
        }

        .main-content h1 {
            font-size: 2rem;
            color: #333;
            margin-bottom: 20px;
        }

        .main-content p {
            font-size: 1.1rem;
            color: #555;
            line-height: 1.6;
        }

        .form-section {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .form-section h4 {
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .form-section input,
        .form-section select,
        .form-section textarea {
            margin-bottom: 15px;
        }

        .caret-icon {
            transition: transform 0.3s;
        }

        /* Rotate caret on collapse show */
        #studentsMenu.show+a .caret-icon {
            transform: rotate(180deg);
        }
    </style>
</head>

<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <img src="a-removebg-preview.png" alt="School Logo">
            <p>CEBUANO ELEMENTARY SCHOOL</p>
        </div>
        <div class="nav-items">
        <a href="teacher_dashboard.php" class="nav_link">Dashboard</a>
                <a href="teacher_addstudents.php" class="nav_link">Add Students</a>
                <a href="teacher_addgrades.php" class="nav_link">Grades</a>
        </div>
        <a href="teacher_logout.php" class="btn-logout">Logout</a>
    </div>

    <div class="main-content">
            <h2>Add New Student</h2>
            <?php echo $message; ?>
            <form method="POST" class="form-section" enctype="multipart/form-data">
                <div class="row">
                <div class="col-md-6">
                    <label for="studentNumber" class="form-label">Student Number</label>
                    <input type="text" name="student_number" id="studentNumber" class="form-control" placeholder="Enter student number" required>
                </div>
                <div class="col-md-6">
                    <label for="studentName" class="form-label">Student Name</label>
                    <input type="text" name="student_name" id="studentName" class="form-control" placeholder="Enter student name" required>
                </div>
                <div class="col-md-6">
                    <label for="dateOfBirth" class="form-label">Date of Birth</label>
                    <input type="date" name="date_of_birth" id="dateOfBirth" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label for="guardianName" class="form-label">Guardian Name</label>
                    <input type="text" name="guardian_name" id="guardianName" class="form-control" placeholder="Enter guardian name" required>
                </div>
                </div>

                <div class="row">
                <div class="col-md-6">
                    <label for="guardianContact" class="form-label">Guardian Contact</label>
                    <input type="number" name="guardian_contact" id="guardianContact" class="form-control" placeholder="Enter guardian contact" required>
                </div>
                <div class="col-md-6">
                    <label for="dateEnrolled" class="form-label">Date Enrolled</label>
                    <input type="date" name="date_enrolled" id="dateEnrolled" class="form-control" required>
                </div>

                <div class="col-md-6">
                    <label for="classId" class="form-label">Class Name</label>
                    <select name="class_id" id="classId" class="form-control" required>
                        <option value="" disabled selected>Select Class</option>
                        <?php while ($class = $classes->fetch_assoc()) { ?>
                            <option value="<?php echo $class['class_id']; ?>"><?php echo $class['class_name']; ?></option>
                        <?php } ?>
                    </select>
                </div>
                
                <div class="col-md-6">
                    <label for="teacherId" class="form-label">Teacher Name</label>
                    <select name="teacher_id" id="teacherId" class="form-control" required>
                        <option value="" disabled selected>Select Teacher</option>
                        <?php while ($teacher = $teachers->fetch_assoc()) { ?>
                            <option value="<?php echo $teacher['teacher_id']; ?>"><?php echo $teacher['teacher_name']; ?></option>
                        <?php } ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label for="photo" class="form-label">Upload Photo</label>
                    <input type="file" name="photo" id="photo" class="form-control" accept="image/*" required>
                </div>
                <button type="submit" class="btn btn-primary mt-4">Add Student</button>
            </form>
        </div>
        </div>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>