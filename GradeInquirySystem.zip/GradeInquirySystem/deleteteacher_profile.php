<?php
require 'connection.php';

$teacher_id = isset($_GET['teacher_id']) ? $_GET['teacher_id'] : null;

if (!$teacher_id) {
    die('No ID or Invalid ID');
}

// Start a transaction
$conn->begin_transaction();

try {
    // Step 1: Delete related entries in classes table
    $sqlClasses = "DELETE FROM classes WHERE teacher_id = ?";
    $stmtClasses = $conn->prepare($sqlClasses);
    $stmtClasses->bind_param("i", $teacher_id);
    $stmtClasses->execute();
    $stmtClasses->close();

    // Step 2: Delete the teacher entry from teachers table
    $sqlTeacher = "DELETE FROM teachers WHERE teacher_id = ?";
    $stmtTeacher = $conn->prepare($sqlTeacher);
    $stmtTeacher->bind_param("i", $teacher_id);
    $stmtTeacher->execute();
    $stmtTeacher->close();

    // Commit the transaction
    $conn->commit();

    header("Location: admin_dashboard.php?status=deleted");
} catch (Exception $e) {
    // Rollback the transaction if an error occurs
    $conn->rollback();
    die("Error deleting records: " . $e->getMessage());
}

$conn->close();
exit();
?>
