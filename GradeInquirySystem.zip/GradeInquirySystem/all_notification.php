<?php
require 'connection.php';

$student_id = $_SESSION['guardian_id'] ?? 0;
$notifications_query = "SELECT message, date_created FROM notifications WHERE student_id = ? ORDER BY date_created DESC";
$notifications_stmt = $conn->prepare($notifications_query);
$notifications_stmt->bind_param("i", $student_id);
$notifications_stmt->execute();
$notifications_result = $notifications_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>All Notifications</title>
</head>
<body>
    <div class="container mt-4">
        <h1>All Notifications</h1>
        <?php if ($notifications_result->num_rows > 0): ?>
            <ul class="list-group">
                <?php while ($notification = $notifications_result->fetch_assoc()): ?>
                    <li class="list-group-item">
                        <p><?php echo htmlspecialchars($notification['message']); ?></p>
                        <small><?php echo date('F j, Y, g:i a', strtotime($notification['date_created'])); ?></small>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>No notifications found.</p>
        <?php endif; ?>
<br>
        <a href="studentdashboard.php" class="btn btn-primary">Back</a>
    </div>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
