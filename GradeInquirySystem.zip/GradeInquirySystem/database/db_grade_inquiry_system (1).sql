-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2024 at 03:05 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_grade_inquiry_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `class_id` int(11) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`class_id`, `class_name`, `teacher_id`) VALUES
(20, 'Grade 1 - Carrot', 32),
(21, 'Grade 2 - Banana', 33),
(22, 'Grade 3 - Ruby', 34),
(23, 'Grade 4 - Narra', 35),
(24, 'Grade 5 - Polite', 36),
(25, 'Grade 6 - Rizal', 37);

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `grade_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `grade` decimal(4,2) DEFAULT NULL,
  `description` text NOT NULL,
  `date_recorded` date DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`grade_id`, `student_id`, `subject_id`, `grade`, `description`, `date_recorded`, `teacher_id`) VALUES
(29, 18, 15, 92.00, 'May kulang ka isa ka acitivity worth 50points', '2024-11-19', 32),
(30, 24, 15, 75.00, 'Sigi absent', '2024-11-22', 33),
(31, 18, 16, 76.00, 'Excellent kulang ka isa ka activity', '1111-11-11', 34);

-- --------------------------------------------------------

--
-- Table structure for table `inquiries`
--

CREATE TABLE `inquiries` (
  `inquiry_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subject` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `student_id`, `message`, `date_created`, `is_read`) VALUES
(18, 24, 'A new grade has been added for subject Math.', '2024-11-22 01:51:26', 0),
(21, 18, '123', '2024-11-28 13:26:31', 0);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `student_number` varchar(20) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `date_of_birth` date NOT NULL,
  `guardian_name` varchar(100) DEFAULT NULL,
  `guardian_contact` varchar(15) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `date_enrolled` date DEFAULT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `student_number`, `student_name`, `date_of_birth`, `guardian_name`, `guardian_contact`, `class_id`, `date_enrolled`, `photo`) VALUES
(18, '1001', 'Ricky Mercado', '2024-11-18', 'Juanito', '09092034481', 20, '2024-11-18', 'studentphoto/360_F_888776309_FNK3sVbHnxg8tNHe6P4BlSTPWk1Lp4vV.webp'),
(19, '1002', 'James Rei Crackers', '2005-11-02', 'Rei Borg', '09092034481', 21, '2024-11-18', 'studentphoto/360_F_888776309_FNK3sVbHnxg8tNHe6P4BlSTPWk1Lp4vV.webp'),
(20, '1003', 'Wesley Borja', '2005-04-30', 'Welmer Borja', '09092034481', 22, '2024-11-18', 'studentphoto/360_F_888776309_FNK3sVbHnxg8tNHe6P4BlSTPWk1Lp4vV.webp'),
(21, '1004', 'George Bugwak', '2005-01-23', 'Pual England', '09092034481', 23, '2024-11-18', 'studentphoto/360_F_888776309_FNK3sVbHnxg8tNHe6P4BlSTPWk1Lp4vV.webp'),
(22, '1005', 'Toto Banakaw', '2005-07-28', 'Junel Banakaw', '09092034481', 24, '2024-11-18', 'studentphoto/360_F_888776309_FNK3sVbHnxg8tNHe6P4BlSTPWk1Lp4vV.webp'),
(23, '1006', 'Jalmer Barimar', '2024-11-18', 'Halmer Barimaw', '09092034481', 25, '2024-11-18', 'studentphoto/360_F_888776309_FNK3sVbHnxg8tNHe6P4BlSTPWk1Lp4vV.webp'),
(24, '2023-00316', 'Bacas Toto', '2005-02-19', 'Juanito', '09092034481', 20, '2024-11-22', 'studentphoto/360_F_888776309_FNK3sVbHnxg8tNHe6P4BlSTPWk1Lp4vV.webp');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subject_id` int(11) NOT NULL,
  `subject_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_id`, `subject_name`) VALUES
(15, 'Math'),
(16, 'Science'),
(17, 'Filipino'),
(18, 'English'),
(19, 'ESP'),
(20, 'HeKaSi');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` int(11) NOT NULL,
  `teacher_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `birthdate` date NOT NULL,
  `address` text NOT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `teacher_name`, `email`, `contact_number`, `birthdate`, `address`, `photo`) VALUES
(32, 'Alya Montero', 'montero@gmail.com', '09092034481', '2005-02-19', 'Prk Mahusay Poblacion Polomolok South Cotabato', 'photo/1.jfif'),
(33, 'Kaoruko Magallanes', 'kaoruko11@gmail.com', '09092034481', '2005-03-21', 'Prk Marbel Poblacion Polomolok South Cotabato', 'photo/2.jfif'),
(34, 'Chiinatsu Upuan', 'chiinat2@gmail.com', '09092034481', '2005-06-28', 'Prk Masipag Poblacion Polomolok South Cotabato', 'photo/3.jfif'),
(35, 'Shiina Gonzales', 'Shiinaagon112@gmail.com', '09092034481', '2005-02-12', 'Prk Manatad Polomolok South Cotabato', 'photo/4.jfif'),
(36, 'Kafka Bartolomeo', 'kafkabar123@gmail.com', '09092034481', '2005-07-08', 'Prk Manatad Polomolok South Cotabato', 'photo/5.jfif'),
(37, 'Jessica Marabe', 'jess21@gmail.com', '09092034481', '2005-12-12', 'Prk Mahusay Poblacion Polomolok South Cotabato', 'photo/6.jfif');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_role` varchar(100) NOT NULL,
  `guardian_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `user_role`, `guardian_id`, `teacher_id`) VALUES
(16, 'AlyaMontero', '$2y$10$rnfKEK7W8YwuEPvThuHrGuKPqRx0YxGe/R/XdckRPpwsrR9ViBqnq', 'Teacher', NULL, 32),
(17, 'KaorukoMagallanes', '$2y$10$CDn3Vu7MzuqbDEwdCxrlR.nSzI4FKxm1MSBMXlF0pJHUUyYIL63lK', 'Teacher', NULL, 33),
(18, 'ChiinatsuUpuan', '$2y$10$NiQlojo0L.h3Y2zK3slWx.L.19IPVX2zOjk6vUjjfn8WMor0KhVhC', 'Teacher', NULL, 34),
(19, 'ShiinaGonzales', '$2y$10$2Jn2JqHf9TwALQragPadAOAXmmCqNk45YNCaz3dxs9pjhjKApmrIi', 'Teacher', NULL, 35),
(20, 'KafkaBartolomeo', '$2y$10$6YnP9YyM3P3ROMmRhfc5v.mMSA6QRhjJcAGa05F8vLq1vRbVT9LI2', 'Teacher', NULL, 36),
(21, 'JessicaMarabe', '$2y$10$oBTq9Y5r/zMQHYWiIwZg6eCzRi/aGl6NO9BS7bOEvt5aVqfcMIK4u', 'Teacher', NULL, 37),
(22, 'RickyMercado', '$2y$10$f.e/Dic5/J4qx73m579/6OMbOepFrk3WrX9vFIRHxNJr0CuatflCi', 'Student', 18, NULL),
(23, 'JamesReiCrackers', '$2y$10$Tz2tOWK6LugmZrC0H1zW2uhwW8i8sBLxU.XoRM/to44ieZgeAC5rW', 'Student', 19, NULL),
(24, 'WesleyBorja', '$2y$10$Ns7bOSvg4jLnPjAFhk22Ou6jd27U.szbeyaEko6TNh6PcK.NPc1gG', 'Student', 20, NULL),
(25, 'GeorgeBugwak', '$2y$10$NUreahv4npvkEN2o2g53peDViBErqM2SzkQHb2P7.MhhueYYrfbKW', 'Student', 21, NULL),
(26, 'TotoBanakaw', '$2y$10$tgSUS5DeC/1xXv4Sy6hNh.qEqVXtrobsJGVwgk2hDOFg96FjiAFfS', 'Student', 22, NULL),
(27, 'JalmerBarimar', '$2y$10$UBhRz07M1Yg/ugdUk6rSLufB1ceASQUUiLZ35DwjX7NUhrfrt4S.m', 'Student', 23, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`class_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`grade_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `inquiries`
--
ALTER TABLE `inquiries`
  ADD PRIMARY KEY (`inquiry_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `guardian_id` (`guardian_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `grade_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `inquiries`
--
ALTER TABLE `inquiries`
  MODIFY `inquiry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `classes`
--
ALTER TABLE `classes`
  ADD CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`);

--
-- Constraints for table `grades`
--
ALTER TABLE `grades`
  ADD CONSTRAINT `grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  ADD CONSTRAINT `grades_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`),
  ADD CONSTRAINT `grades_ibfk_3` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`);

--
-- Constraints for table `inquiries`
--
ALTER TABLE `inquiries`
  ADD CONSTRAINT `inquiries_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`guardian_id`) REFERENCES `students` (`student_id`),
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
