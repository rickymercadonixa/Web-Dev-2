<?php
require 'connection.php';

$search_query = $_GET['search'] ?? '';

$query = "SELECT * FROM users";

$result = null;

if (!empty($search_query)) {
    $query .= " WHERE username LIKE ? OR user_role LIKE ?";
    $stmt = $conn->prepare($query);
    $search_param = "%" . $search_query . "%";
    $stmt->bind_param("ss", $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Account List</title>
    <style>
        /* General styling */
        body {
            background-color: #f8f9fa;
            color: #333;
        }

        .container {
            max-width: 1100px;
        }

        /* Header styling */
        .header {
            padding: 20px;
            text-align: center;
            background-color: #004d99;
            color: #fff;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        /* Table styling */
        .table {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .table th {
            background-color: #004d99;
            color: #fff;
            text-align: center;
        }

        .table td {
            vertical-align: middle;
            text-align: center;
        }

        .table-img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50%;
        }

        /* Hover effects */
        .table tr:hover {
            background-color: #e6f7ff;
        }

        /* Back button styling */
        .back-button {
            margin-top: 20px;
            background-color: #004d99;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .back-button:hover {
            background-color: #fff;
        }

        /* Action button styling */
        .action-btn {
            margin: 0 5px;
            padding: 5px 10px;
            border-radius: 5px;
            color: #fff;
        }

        .update-btn {
            background-color: #28a745;
        }

        .delete-btn {
            background-color: #dc3545;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .header h2 {
                font-size: 1.5rem;
            }

            .table-img {
                width: 40px;
                height: 40px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header mt-4">
            <h2>Account List</h2>
            <p>This is where you can manage all the accounts of teachers and students!</p>
        </div>

        <!-- Search Form -->
        <form method="GET" class="input-group mb-3">
            <input type="text" name="search" class="form-control" placeholder="Search by Username or Role" value="<?php echo htmlspecialchars($search_query); ?>">
            <button type="submit" class="btn btn-primary">Search</button>
            <a href="manage_accounts.php" class="btn btn-primary ms-2">Reset</a>
        </form>

        <div class="text-end">
            <a href="admin_dashboard.php" class="btn back-button">Back to Dashboard</a>
        </div>

        <div class="table-responsive mt-3">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $count = 0;
                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            if($count < 5){
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['username']) . "</td>"; 
                            echo "<td>" . htmlspecialchars($row['user_role']) . "</td>";
                            echo "<td>
                                    <a href='update_account.php?id=" . urlencode($row['user_id']) . "' class='action-btn update-btn'>Update</a> 
                                    <br><br>
                                    <a href='delete_account.php?id=" . urlencode($row['user_id']) . "' class='action-btn delete-btn'>Delete</a> 
                                  </td>";
                            echo "</tr>";
                            $count++;
                        }
                    }
                    } else {
                        echo "<tr><td colspan='3' class='text-center'>No accounts found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <?php if ($result->num_rows > 5): ?>
                        <div class="text-center mt-3">
                            <a href="all_accounts.php" class="btn btn-primary col-md-12">View All Accounts</a>
                        </div>
                    <?php endif; ?>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
