<?php
require 'connection.php';

$message = '';

if (isset($_POST['submit'])) {
  $user = $_POST['user'];
  $pass = $_POST['pass'];

  if (empty($user) || empty($pass)) {
    $message = '<p class="text-danger">Please enter username and password</p>';
  } else {
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    // Check if user exists and verify the password
    if ($row && password_verify($pass, $row['password'])) {
      $_SESSION['user_id'] = $row['user_id'];
      $_SESSION['user_role'] = $row['user_role'];


      if($_SESSION['user_role'] == "student" || $_SESSION['user_role'] == "Student"){
        $_SESSION['guardian_id'] = $row['guardian_id'];
        header("Location: studentdashboard.php");
        exit;
      }elseif($_SESSION['user_role'] == "teacher" || $_SESSION['user_role'] == "Teacher"){
        $_SESSION['teacher_id'] = $row['teacher_id'];
          header("Location: teacher_dashboard.php");
          exit;
      }elseif($_SESSION['user_role'] == "guardian" || $_SESSION['user_role'] == "Guardian"){
        header("Location: student_dashboard.php");
        exit;
    }else{
        $message = '<p class="text-danger" Unauthorized user. </p>';
      }
    } else {
      $message = '<p class="text-danger">Incorrect Credentials! Please try again.</p>';
    }
  }
}
?>


<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
  <div class="login-page">
    <div class="form">

      <h2>Login</h2>
      <?php echo $message; ?>
      <form method="post" class="login-form">
        <input type="text" name="user" placeholder="Username" required="">
        <input type="password" name="pass" placeholder="Password" required="">
        <button type="submit" name="submit">Login</button>
      </form>
      <br>
      <p>Are you admin? <a href="admin_login.php">Login here</a>.</p>
    </div>
  </div>
</body>

</html>


<style>
  * {
    box-sizing: border-box;
  }

  body {
    margin: 0;
    padding: 0;
    font-family: sans-serif;
    background-image: linear-gradient(to right, #667eea, #764ba2);
  }

  .login-page {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
  }

  .form {
    background: #fff;
    max-width: 360px;
    width: 100%;
    padding: 50px 40px;
    border-radius: 10px;
    box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.1);
  }

  .form h2 {
    margin-bottom: 20px;
    color: #333;
    text-align: center;
  }

  .form input {
    border-radius: 5px;
    border: none;
    background: #f0f0f0;
    padding: 10px;
    margin-bottom: 20px;
    width: 100%;
    font-size: 14px;
    color: #333;
  }

  .form input:focus {
    outline: none;
    background: #e6e6e6;
  }

  .form button {
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    padding: 10px;
    width: 100%;
    transition: all 0.2s ease;
    margin-top: 10px;
  }

  .form button:hover {
    background-color: #3e8e41;
  }
</style>