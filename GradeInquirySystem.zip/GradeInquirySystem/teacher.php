<?php
require 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $teacher_name = $_POST['teacher_name'];
    $email = $_POST['email'];
    $contact_number = $_POST['contact_number'];
    $birthdate = $_POST['birthdate'];
    $teacher_address = $_POST['teacher_address'];
    $class_name = $_POST['class_name'];
    $subject_name = $_POST['subject_name'];

    // Handle file upload
    if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == 0) {
        $photo_name = $_FILES['photo']['name'];
        $photo_tmp = $_FILES['photo']['tmp_name'];
        $photo_path = 'photo/' . $photo_name;

        if (move_uploaded_file($photo_tmp, $photo_path)) {
            // Begin a transaction
            $conn->begin_transaction();

            try {
                // Insert into `teachers` table
                $sql = "INSERT INTO teachers (teacher_name, email, contact_number, birthdate, address, photo)
                        VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssss", $teacher_name, $email, $contact_number, $birthdate, $teacher_address, $photo_path);
                $stmt->execute();

                // Check if teacher was inserted successfully
                if ($stmt->affected_rows > 0) {
                    $teacher_id = $conn->insert_id; // Get the last inserted ID for teacher

                    // Insert into `classes` table
                    $sql3 = "INSERT INTO classes (class_name, teacher_id) VALUES (?, ?)";
                    $stmt3 = $conn->prepare($sql3);
                    $stmt3->bind_param("si", $class_name, $teacher_id);
                    $stmt3->execute();

                    $sql4 = "INSERT INTO subjects (subject_name) VALUES (?)";
                    $stmt4 = $conn->prepare($sql3);
                    $stmt4->bind_param("s", $subject_name);
                    $stmt4->execute();

                    // Commit transaction
                    $conn->commit();

                    // Redirect to admin dashboard
                    header("Location: admin_dashboard.php");
                    exit();
                } else {
                    throw new Exception("Error inserting teacher data.");
                }
            } catch (Exception $e) {
                // Rollback transaction on failure
                $conn->rollback();
                echo "Failed to insert data: " . $e->getMessage();
            }
        } else {
            echo 'Error uploading file.';
        }
    } else {
        echo 'No file uploaded. Please try again.';
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Admin Dashboard - Add Teachers</title>
    <style>
        body {
            display: flex;
            min-height: 100vh;
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            background-color: #004d99;
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: white;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }

        .sidebar-header img {
            width: 90px;
            height: 90px;
        }

        .sidebar-header p {
            font-size: 1.2rem;
            color: #ffffff;
        }

        .nav-items a {
            display: block;
            text-decoration: none;
            font-size: 1.1rem;
            color: #ffffff;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            transition: background-color 0.3s;
            text-align: center;
        }

        .nav-items a.active,
        .nav-items a:hover {
            background-color: #003366;
        }

        .btn-logout {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn-logout:hover {
            background-color: #c0392b;
        }

        /* Main content styling */
        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #fff;
        }

        .main-content h1 {
            font-size: 2rem;
            color: #333;
            margin-bottom: 20px;
        }

        .main-content p {
            font-size: 1.1rem;
            color: #555;
            line-height: 1.6;
        }

        .form-section {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .form-section h4 {
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .form-section input,
        .form-section select,
        .form-section textarea {
            margin-bottom: 15px;
        }
    </style>
</head>

<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <img src="a-removebg-preview.png" alt="School Logo">
            <p>CEBUANO ELEMENTARY SCHOOL</p>
        </div>
        <div class="nav-items">
            <a href="admin_dashboard.php" class="nav_link">Dashboard</a>
            <a href="teacher.php" class="nav_link">Teachers</a>
            <a href="students.php" class="nav_link">Students</a>
        </div>
        <a href="admin_logout.php" class="btn-logout">Logout</a>
    </div>

    <div class="main-content">
        <h2 class="text-left">Add New Teacher</h2>
        <form method="POST" class="form-section" enctype="multipart/form-data">
            <div class="row">
                <h4>Personal Information</h4>
                <div class="col-md-6">
                    <label for="teacherName" class="form-label">Full Name</label>
                    <input type="text" name="teacher_name" id="teacherName" class="form-control" placeholder="Enter full name" required>
                </div>
                <div class="col-md-6">
                    <label for="teacherEmail" class="form-label">Email</label>
                    <input type="email" name="email" id="teacherEmail" class="form-control" placeholder="Enter email" required>
                </div>
                <div class="col-md-6">
                    <label for="teacherPhone" class="form-label">Phone</label>
                    <input type="text" name="contact_number" id="teacherPhone" class="form-control" placeholder="Enter phone number" required>
                </div>
                <div class="col-md-6">
                    <label for="teacherRole" class="form-label">Birthdate</label>
                    <input type="date" class="form-control" name="birthdate">
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <label for="teacherAddress" class="form-label">Address</label>
                    <input type="text" name="teacher_address" id="teacherAddress" class="form-control" placeholder="Enter address" required>
                </div>
                <div class="col-md-6">
                    <label for="photo" class="form-label">Photo</label>
                    <input type="file" class="form-control" id="photo" name="photo" accept="image/*" required>
                </div>
            </div>

            <h4>Class Information</h4>
            <div class="row">
                <div class="col-md-6">
                    <label for="classname" class="form-label">Class name</label>
                    <input type="text" class="form-control" id="photo" name="class_name" placeholder="Enter Class name" required>
                </div>
            </div>

                <button type="submit" name="submit" class="btn btn-primary mt-4 col-md-12">Add Teacher</button>
        </form>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>