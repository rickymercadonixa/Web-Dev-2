<?php
require 'connection.php';

$student_id = $_SESSION['guardian_id'] ?? 0;

$query = "SELECT student_name FROM students WHERE student_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
$student_name = $result->fetch_assoc()['student_name'] ?? 'Student';

$grades_data = null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_number = $_POST['student_number'];
    $subject_name = $_POST['subject'];

    // Lookup student_id using student_number
    $query1 = "SELECT student_id FROM students WHERE student_number = ?";
    $stmt1 = $conn->prepare($query1);
    $stmt1->bind_param("i", $student_number);
    $stmt1->execute();
    $result1 = $stmt1->get_result();
    $student_id = $result1->fetch_assoc()['student_id'] ?? null;

    if ($student_id) {
        // Get subject_id based on the provided subject name
        $subject_query = "SELECT subject_id FROM subjects WHERE subject_name = ?";
        $subject_stmt = $conn->prepare($subject_query);
        $subject_stmt->bind_param("s", $subject_name);
        $subject_stmt->execute();
        $subject_result = $subject_stmt->get_result();
        $subject_id = $subject_result->fetch_assoc()['subject_id'] ?? null;

        if ($subject_id) {
            // Fetch the grade and description from the grades table
            $grade_query = "SELECT grade, description FROM grades WHERE student_id = ? AND subject_id = ?";
            $grade_stmt = $conn->prepare($grade_query);
            $grade_stmt->bind_param("ii", $student_id, $subject_id);
            $grade_stmt->execute();
            $grade_stmt->store_result();
            $grade_stmt->bind_result($grade, $description);

            if ($grade_stmt->num_rows > 0) {
                $grades_data = [];
                while ($grade_stmt->fetch()) {
                    $grades_data[] = ['subject_name' => $subject_name, 'grade' => $grade, 'description' => $description];
                }
            } else {
                $grades_data = 'No grade available for this subject.';
            }
            $grade_stmt->close();
        } else {
            $grades_data = 'Subject not found.';
        }
    } else {
        $grades_data = 'Student number not found.';
    }

    $stmt->close();
    $conn->close();
}

if (isset($_POST['generate_report'])) {
    if (is_array($grades_data) && !empty($grades_data)) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=grades_report.csv');

        $output = fopen('php://output', 'w');

        fputcsv($output, ['Subject Name', 'Grade', 'Description']);

        foreach ($grades_data as $data) {
            fputcsv($output, [$data['subject_name'], $data['grade'], $data['description']]);
        }

        fclose($output);
        exit;
    } else {
        $grades_data = 'No data available to generate the report.';
    }
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <title>Student Dashboard</title>
    <style>
        body {
            display: flex;
            min-height: 100vh;
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }

        /* Sidebar styling */
        .sidebar {
            width: 250px;
            background-color: #004d99;
            padding: 30px 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .sidebar img {
            width: 100%;
            margin-bottom: 20px;
        }

        .sidebar p {
            font-size: 1.2rem;
            color: #ffffff;
            margin-bottom: 30px;
            text-align: center;
        }

        .nav-items a {
            display: block;
            text-decoration: none;
            font-size: 1.1rem;
            color: #ffffff;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: left;
            transition: background-color 0.3s;
        }

        .nav-items a.active, .nav-items a:hover {
            background-color: #003366;
        }

        .btn-logout {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            margin-top: auto;
            transition: background-color 0.3s;
        }

        .btn-logout:hover {
            background-color: #c0392b;
        }

        /* Main content styling */
        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #fff;
        }

        .main-content h1 {
            font-size: 2rem;
            color: #333;
            margin-bottom: 20px;
        }

        .main-content p {
            font-size: 1.1rem;
            color: #555;
            line-height: 1.6;
        }

        .table {
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <img src="a-removebg-preview.png" alt="School Logo">
        <p>CEBUANO ELEMENTARY SCHOOL</p>
        <div class="nav-items">
            <a href="studentdashboard.php" class="nav_link">Dashboard</a>
            <a href="student_inquiry.php" class="nav_link">Inquiry Form</a>
        </div>
        <a href="student_logout.php" class="btn-logout">Logout</a>
    </div>

    <div class="main-content">
        <h1>Welcome to <?php echo htmlspecialchars($student_name); ?>!</h1>

        <form action="" method="POST">
    <h1 class="form-title">Grade Inquiry Form</h1>
    <div class="form-group">
        <label for="student_number">Student Number:</label>
        <input type="text" id="student_number" name="student_number" class="form-control" placeholder="Enter student number" required>
    </div>
    <div class="form-group">
        <label for="subject">Subject:</label>
        <input type="text" id="subject" name="subject" class="form-control" placeholder="Enter subject" require>
    </div>
    <div class="form-group">
        <button type="submit" class="btn-submit">Inquire</button>
        <button type="submit" name="generate_report" class="btn-submit mt-2">Generate Report</button>
    </div>
</form>


        <?php if ($grades_data !== null): ?>
            <?php if (is_array($grades_data)): ?>
                <table class="table table-bordered text-center">
                    <thead>
                        <tr><th>Subject</th><th>Grade</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($grades_data as $data): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($data['subject_name']); ?></td>
                                <td><?php echo htmlspecialchars($data['grade']); ?></td>
                                <td><?php echo htmlspecialchars($data['description']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h2><?php echo htmlspecialchars($grades_data); ?></h2>
            <?php endif; ?>
        <?php endif; ?>

    </div>     
</body>
</html>

<style>
    /* Form styling */
.form-title {
    font-size: 2rem;
    color: #004d99;
    margin-bottom: 20px;
    text-align: center;
    font-weight: bold;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    font-size: 1.1rem;
    color: #333;
    display: block;
    margin-bottom: 8px;
}

.form-group input {
    width: 100%;
    padding: 10px;
    font-size: 1rem;
    border: 2px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
    margin-top: 5px;
    transition: border-color 0.3s;
}

.form-group input:focus {
    border-color: #004d99;
    outline: none;
}

.btn-submit {
    background-color: #004d99;
    color: white;
    font-size: 1.2rem;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    width: 100%;
    transition: background-color 0.3s;
}

.btn-submit:hover {
    background-color: #003366;
}

</style>
